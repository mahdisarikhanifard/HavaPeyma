package com.example.havapeyma

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var content: LinearLayout
    private lateinit var cityTitle: TextView
    private lateinit var mainWeather: TextView
    private lateinit var details: TextView
    private lateinit var hourly: TextView
    private lateinit var daily: TextView
    private lateinit var air: TextView
    private var latitude = 51.5072
    private var longitude = -0.1276
    private var city = "لندن"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("weather", Context.MODE_PRIVATE)
        latitude = prefs.getString("lat", "51.5072")?.toDoubleOrNull() ?: 51.5072
        longitude = prefs.getString("lon", "-0.1276")?.toDoubleOrNull() ?: -0.1276
        city = prefs.getString("city", "لندن") ?: "لندن"
        buildUi()
        loadWeather()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF4F8FA.toInt()) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 18); setBackgroundColor(0xFF167D9A.toInt()) }
        cityTitle = TextView(this).apply { textSize = 22f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER; text = city }
        val subtitle = TextView(this).apply { text = "آب‌وهوا، پیش‌بینی و کیفیت هوا"; textSize = 13f; gravity = Gravity.CENTER; setTextColor(0xFFE4F4F7.toInt()) }
        header.addView(cityTitle); header.addView(subtitle)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(12, 10, 12, 10) }
        val gps = Button(this).apply { text = "موقعیت من"; setOnClickListener { requestGps() } }
        val search = Button(this).apply { text = "انتخاب شهر"; setOnClickListener { showCitySearch() } }
        actions.addView(gps, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); actions.addView(search, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 4, 16, 20) }
        mainWeather = sectionText(30f, 0xFF164B5B.toInt(), true)
        details = sectionText(15f, 0xFF285A68.toInt())
        hourly = sectionText(14f, 0xFF285A68.toInt())
        daily = sectionText(14f, 0xFF285A68.toInt())
        air = sectionText(14f, 0xFF285A68.toInt())
        content.addView(mainWeather); content.addView(details)
        addHeading("پیش‌بینی ساعتی"); content.addView(hourly)
        addHeading("پیش‌بینی روزانه"); content.addView(daily)
        addHeading("کیفیت هوا و تابش فرابنفش"); content.addView(air)
        scroll.addView(content)
        root.addView(header); root.addView(actions); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun sectionText(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size; setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(4, 8, 4, 12); text = "در حال دریافت اطلاعات..."
    }

    private fun addHeading(label: String) {
        content.addView(TextView(this).apply { text = label; textSize = 18f; setTextColor(0xFF167D9A.toInt()); setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(4, 18, 4, 4) })
    }

    private fun loadWeather() {
        mainWeather.text = "در حال دریافت وضعیت هوا..."
        executor.execute {
            try {
                val weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&hourly=temperature_2m,precipitation_probability,uv_index&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max&forecast_days=5&timezone=auto"
                val w = JSONObject(getUrl(weatherUrl))
                val current = w.getJSONObject("current")
                val airUrl = "https://air-quality-api.open-meteo.com/v1/air-quality?latitude=$latitude&longitude=$longitude&current=pm10,pm2_5,us_aqi,european_aqi&timezone=auto"
                val a = try { JSONObject(getUrl(airUrl)).optJSONObject("current") ?: JSONObject() } catch (_: Exception) { JSONObject() }
                val temp = current.optDouble("temperature_2m", Double.NaN)
                val feels = current.optDouble("apparent_temperature", Double.NaN)
                val humidity = current.optInt("relative_humidity_2m", -1)
                val wind = current.optDouble("wind_speed_10m", Double.NaN)
                val code = current.optInt("weather_code", -1)
                val hourlyData = w.optJSONObject("hourly") ?: JSONObject()
                val dailyData = w.optJSONObject("daily") ?: JSONObject()
                val hTimes = hourlyData.optJSONArray("time")
                val hTemps = hourlyData.optJSONArray("temperature_2m")
                val hRain = hourlyData.optJSONArray("precipitation_probability")
                val dTimes = dailyData.optJSONArray("time")
                val dMax = dailyData.optJSONArray("temperature_2m_max")
                val dMin = dailyData.optJSONArray("temperature_2m_min")
                val dUv = dailyData.optJSONArray("uv_index_max")
                val hourText = buildString {
                    if (hTimes != null && hTemps != null) for (i in 0 until minOf(6, hTimes.length(), hTemps.length())) {
                        val time = hTimes.optString(i).substringAfter('T')
                        append("$time  ${hTemps.optDouble(i).toInt()}°")
                        if (hRain != null) append("  بارش ${hRain.optInt(i)}٪")
                        append("\n")
                    }
                }
                val dayText = buildString {
                    if (dTimes != null && dMax != null && dMin != null) for (i in 0 until minOf(5, dTimes.length(), dMax.length(), dMin.length())) {
                        append("${dTimes.optString(i)}   بیشینه ${dMax.optDouble(i).toInt()}° / کمینه ${dMin.optDouble(i).toInt()}°")
                        if (dUv != null) append("   UV ${dUv.optDouble(i).toInt()}")
                        append("\n")
                    }
                }
                val airText = "شاخص آمریکا AQI: ${format(a.optDouble("us_aqi", Double.NaN))}\nشاخص اروپا: ${format(a.optDouble("european_aqi", Double.NaN))}\nذرات PM2.5: ${format(a.optDouble("pm2_5", Double.NaN))} µg/m³\nذرات PM10: ${format(a.optDouble("pm10", Double.NaN))} µg/m³\nUV بیشینه امروز: ${if (dUv != null && dUv.length() > 0) dUv.optDouble(0).toInt().toString() else "--"}"
                val currentText = "${format(temp)}°  ${weatherDescription(code)}"
                val detailsText = "احساس‌شده ${format(feels)}°   |   رطوبت ${if (humidity >= 0) "$humidity٪" else "--"}   |   باد ${format(wind)} km/h"
                getSharedPreferences("weather", MODE_PRIVATE).edit().putString("temp", "${format(temp)}°").putString("description", weatherDescription(code)).putString("details", "رطوبت ${if (humidity >= 0) "$humidity٪" else "--"} · باد ${format(wind)} km/h").putString("city", city).putString("lat", latitude.toString()).putString("lon", longitude.toString()).apply()
                runOnUiThread {
                    cityTitle.text = city
                    mainWeather.text = currentText
                    details.text = detailsText
                    hourly.text = hourText.ifBlank { "اطلاعات ساعتی در دسترس نیست" }
                    daily.text = dayText.ifBlank { "اطلاعات روزانه در دسترس نیست" }
                    air.text = airText
                    sendBroadcast(Intent(this, WeatherWidgetProvider::class.java).setAction("com.example.havapeyma.UPDATE_WIDGET"))
                }
            } catch (e: Exception) {
                runOnUiThread { mainWeather.text = "دریافت اطلاعات ناموفق بود"; details.text = "اتصال اینترنت را بررسی کنید و دوباره برنامه را باز کنید.\n${e.message ?: "خطای شبکه"}" }
            }
        }
    }

    private fun format(value: Double): String = if (value.isNaN() || value.isInfinite()) "--" else String.format(Locale.US, "%.0f", value)

    private fun getUrl(address: String): String {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000; connection.readTimeout = 15000; connection.requestMethod = "GET"
        return try { connection.inputStream.bufferedReader().use { it.readText() } } finally { connection.disconnect() }
    }

    private fun weatherDescription(code: Int): String = when (code) {
        0 -> "آسمان صاف"; 1 -> "عمدتاً صاف"; 2 -> "نیمه‌ابری"; 3 -> "ابری"
        45, 48 -> "مه‌آلود"; 51, 53, 55 -> "نم‌نم باران"; 56, 57 -> "باران یخ‌زن"
        61, 63, 65 -> "بارانی"; 66, 67 -> "باران یخ‌زن"; 71, 73, 75, 77 -> "برفی"
        80, 81, 82 -> "رگبار باران"; 85, 86 -> "رگبار برف"; 95, 96, 99 -> "رعدوبرق"; else -> "وضعیت نامشخص"
    }

    private fun showCitySearch() {
        val input = EditText(this).apply { hint = "نام شهر؛ مانند شیراز" }
        AlertDialog.Builder(this).setTitle("جست‌وجوی شهر").setView(input)
            .setPositiveButton("جست‌وجو") { _, _ -> searchCity(input.text.toString().trim()) }
            .setNegativeButton("انصراف", null).show()
    }

    private fun searchCity(query: String) {
        if (query.isBlank()) return
        executor.execute {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val json = JSONObject(getUrl("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=fa&format=json"))
                val results = json.optJSONArray("results")
                if (results == null || results.length() == 0) throw Exception("شهری با این نام پیدا نشد")
                val item = results.getJSONObject(0)
                latitude = item.getDouble("latitude"); longitude = item.getDouble("longitude")
                city = item.optString("name", query)
                val country = item.optString("country", "")
                if (country.isNotBlank()) city += "، $country"
                getSharedPreferences("weather", MODE_PRIVATE).edit().putString("lat", latitude.toString()).putString("lon", longitude.toString()).putString("city", city).apply()
                runOnUiThread { cityTitle.text = city; loadWeather() }
            } catch (e: Exception) { runOnUiThread { Toast.makeText(this, e.message ?: "خطا در جست‌وجو", Toast.LENGTH_LONG).show() } }
        }
    }

    private fun requestGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 41); return
        }
        try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            val location: Location? = manager.getProviders(true).asSequence().mapNotNull { provider -> try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null } }.maxByOrNull { it.time }
            if (location == null) { Toast.makeText(this, "موقعیت در دسترس نیست؛ GPS را روشن کنید یا شهر را جست‌وجو کنید.", Toast.LENGTH_LONG).show(); return }
            latitude = location.latitude; longitude = location.longitude; city = "موقعیت من"
            getSharedPreferences("weather", MODE_PRIVATE).edit().putString("lat", latitude.toString()).putString("lon", longitude.toString()).putString("city", city).apply()
            cityTitle.text = city; loadWeather()
        } catch (_: SecurityException) { Toast.makeText(this, "اجازه مکان‌یابی داده نشد", Toast.LENGTH_SHORT).show() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) requestGps()
        else if (requestCode == 41) Toast.makeText(this, "برای استفاده از GPS باید اجازه مکان‌یابی بدهید.", Toast.LENGTH_LONG).show()
    }
}

package com.example.havapeyma

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class WeatherWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        refresh(context, manager, ids)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == "com.example.havapeyma.UPDATE_WIDGET") {
            val manager = AppWidgetManager.getInstance(context)
            refresh(context, manager, manager.getAppWidgetIds(android.content.ComponentName(context, WeatherWidgetProvider::class.java)))
        }
    }

    private fun refresh(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("weather", Context.MODE_PRIVATE)
        val city = prefs.getString("city", "هوا پیما") ?: "هوا پیما"
        val temp = prefs.getString("temp", "--°") ?: "--°"
        val desc = prefs.getString("description", "برای به‌روزرسانی برنامه را باز کنید") ?: ""
        val details = prefs.getString("details", "") ?: ""
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.weather_widget)
            views.setTextViewText(R.id.widget_city, city)
            views.setTextViewText(R.id.widget_temp, temp)
            views.setTextViewText(R.id.widget_desc, desc)
            views.setTextViewText(R.id.widget_details, details)
            val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
            if (launch != null) views.setOnClickPendingIntent(R.id.widget_city, android.app.PendingIntent.getActivity(context, 0, launch, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE))
            manager.updateAppWidget(id, views)
        }
        // Refresh the saved values periodically when Android invokes the widget update.
        if (ids.isNotEmpty()) {
            val lat = prefs.getString("lat", "51.5072") ?: "51.5072"
            val lon = prefs.getString("lon", "-0.1276") ?: "-0.1276"
            EXECUTOR.execute {
                try {
                    val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&timezone=auto")
                    val c = url.openConnection() as HttpURLConnection
                    c.connectTimeout = 10000; c.readTimeout = 10000
                    val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() }); c.disconnect()
                    val current = json.getJSONObject("current")
                    val code = current.optInt("weather_code", -1)
                    val description = when (code) { 0 -> "صاف"; 1 -> "عمدتاً صاف"; 2 -> "نیمه‌ابری"; 3 -> "ابری"; 45,48 -> "مه‌آلود"; in 51..67 -> "بارانی"; in 71..77 -> "برفی"; in 80..82 -> "رگبار"; in 95..99 -> "رعدوبرق"; else -> "وضعیت هوا" }
                    prefs.edit().putString("temp", "${current.optDouble("temperature_2m").toInt()}°").putString("description", description).putString("details", "رطوبت ${current.optInt("relative_humidity_2m")}٪ · باد ${current.optDouble("wind_speed_10m").toInt()} km/h").apply()
                    val updated = RemoteViews(context.packageName, R.layout.weather_widget)
                    updated.setTextViewText(R.id.widget_city, city)
                    updated.setTextViewText(R.id.widget_temp, prefs.getString("temp", "--°"))
                    updated.setTextViewText(R.id.widget_desc, description)
                    updated.setTextViewText(R.id.widget_details, prefs.getString("details", ""))
                    ids.forEach { manager.updateAppWidget(it, updated) }
                } catch (_: Exception) { /* Keep the last known widget values when offline. */ }
            }
        }
    }

    companion object { private val EXECUTOR = Executors.newSingleThreadExecutor() }
}

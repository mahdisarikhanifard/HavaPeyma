package com.example.havapeyma

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.content.Context
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.Instant
import java.time.format.DateTimeFormatter
import android.icu.util.PersianCalendar
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val refreshHandler = Handler(Looper.getMainLooper())
    private val automaticRefresh = object : Runnable {
        override fun run() {
            if (!isFinishing) {
                loadWeather()
                refreshHandler.postDelayed(this, appRefreshIntervalMs())
            }
        }
    }
    private lateinit var content: LinearLayout
    private lateinit var cityTitle: TextView
    private lateinit var mainWeather: TextView
    private lateinit var details: TextView
    private lateinit var hourly: TextView
    private lateinit var daily: TextView
    private lateinit var air: TextView
    private lateinit var multiModel: TextView
    private lateinit var forecastDayButtons: LinearLayout
    private lateinit var selectedDayAnalysis: TextView
    private var selectedForecastDate: String = ""
    private var locationToday: LocalDate = LocalDate.now()
    private var dailyAnalyses: Map<String, DayForecast> = emptyMap()
    private var annualRainfall: AnnualRainfall? = null
    private var latitude = 51.5072
    private var longitude = -0.1276
    private var city = "لندن"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("weather", Context.MODE_PRIVATE)
        latitude = prefs.getString("lat", "51.5072")?.toDoubleOrNull() ?: 51.5072
        longitude = prefs.getString("lon", "-0.1276")?.toDoubleOrNull() ?: -0.1276
        city = prefs.getString("city", "لندن") ?: "لندن"
        buildUi()
        WidgetRefreshScheduler.schedule(this)
        loadWeather()
    }

    override fun onResume() {
        super.onResume()
        refreshHandler.removeCallbacks(automaticRefresh)
        refreshHandler.postDelayed(automaticRefresh, appRefreshIntervalMs())
    }

    override fun onPause() {
        refreshHandler.removeCallbacks(automaticRefresh)
        super.onPause()
    }

    override fun onDestroy() {
        refreshHandler.removeCallbacks(automaticRefresh)
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF3F7FA.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 22, 20, 20)
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF126782.toInt(), 0xFF249CB1.toInt())
            ).apply { cornerRadii = floatArrayOf(0f,0f,0f,0f,28f,28f,28f,28f) }
        }
        val brand = TextView(this).apply {
            text = "☀  هوا پیما"
            textSize = 14f
            setTextColor(0xFFDDF7FA.toInt())
            gravity = Gravity.CENTER
        }
        cityTitle = TextView(this).apply {
            textSize = 25f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD); text = city
            setPadding(0, 8, 0, 2)
        }
        val subtitle = TextView(this).apply {
            text = "پیش‌بینی دقیق هوا و پایش کیفیت هوا"
            textSize = 12f; gravity = Gravity.CENTER; setTextColor(0xFFE0F4F7.toInt())
        }
        header.addView(brand); header.addView(cityTitle); header.addView(subtitle)
        header.addView(actionButton("☆ ذخیره شهر فعلی", 0xFF0D566C.toInt()) { saveCurrentCity() },
            LinearLayout.LayoutParams(-2, dp(38)).apply { topMargin = dp(8) })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(8))
        }
        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val refresh = actionButton("به‌روزرسانی", 0xFF126782.toInt()) { loadWeather() }
        val gps = actionButton("موقعیت من", 0xFF287F91.toInt()) { requestGps() }
        val search = actionButton("جست‌وجوی شهر", 0xFF287F91.toInt()) { showCitySearch() }
        val saved = actionButton("شهرهای من", 0xFF287F91.toInt()) { showSavedCities() }
        actionRow.addView(refresh, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(4) })
        actionRow.addView(gps, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(4) })
        actionRow.addView(search, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(4) })
        actionRow.addView(saved, LinearLayout.LayoutParams(0, dp(46), 1f))
        actions.addView(actionRow, LinearLayout.LayoutParams(-1, -2))
        actions.addView(actionButton("⌖ انتخاب نقطه از روی نقشه", 0xFF0D566C.toInt()) { showMapPicker() },
            LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) })
        actions.addView(actionButton("تنظیمات زمان به‌روزرسانی", 0xFF496B78.toInt()) { showUpdateSettings() },
            LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(6) })

        val scroll = ScrollView(this).apply { clipToPadding = false }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }
        mainWeather = sectionText(34f, 0xFF123B49.toInt(), true)
        details = sectionText(14f, 0xFF42616C.toInt())
        hourly = sectionText(14f, 0xFF294F5C.toInt())
        daily = sectionText(14f, 0xFF294F5C.toInt())
        air = sectionText(14f, 0xFF294F5C.toInt())
        multiModel = sectionText(14f, 0xFF294F5C.toInt())

        val hero = card()
        hero.addView(TextView(this).apply {
            text = "وضعیت فعلی"; textSize = 14f; setTextColor(0xFF63818A.toInt())
        })
        hero.addView(TextView(this).apply {
            text = "🌤️"; textSize = 48f; gravity = Gravity.CENTER; tag = "weather_sticker"
        })
        hero.addView(mainWeather)
        hero.addView(details)
        content.addView(hero)

        addHeading("پیش‌بینی ساعتی · ۶ ساعت آینده")
        val hourlyCard = card(); hourlyCard.addView(hourly); content.addView(hourlyCard)
        addHeading("پیش‌بینی روزانه · ۵ روز آینده")
        val dailyCard = card(); dailyCard.addView(daily); content.addView(dailyCard)
        addHeading("تحلیل اختصاصی هر روز")
        val dayCard = card()
        val dayScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        forecastDayButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        dayScroll.addView(forecastDayButtons)
        dayCard.addView(dayScroll, LinearLayout.LayoutParams(-1, dp(48)))
        selectedDayAnalysis = sectionText(14f, 0xFF294F5C.toInt())
        dayCard.addView(selectedDayAnalysis)
        content.addView(dayCard)
        addHeading("کیفیت هوا و شاخص UV")
        val airCard = card(); airCard.addView(air); content.addView(airCard)
        addHeading("تحلیل هوشمند چندمنبعی · ۳ مدل")
        val analysisCard = card()
        analysisCard.addView(multiModel)
        analysisCard.addView(actionButton("تحلیل دوباره", 0xFF126782.toInt()) { loadMultiModelAnalysis() },
            LinearLayout.LayoutParams(-2, dp(42)).apply { topMargin = dp(8) })
        content.addView(analysisCard)
        content.addView(TextView(this).apply {
            text = "منبع داده: Open-Meteo  •  مقادیر ممکن است با تأخیر به‌روزرسانی شوند"
            textSize = 10f; setTextColor(0xFF81959C.toInt()); gravity = Gravity.CENTER
            setPadding(4, dp(16), 4, dp(8))
        })
        scroll.addView(content)
        root.addView(header)
        root.addView(actions)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(0xFFFFFFFF.toInt()); cornerRadius = dp(18).toFloat()
            setStroke(dp(1), 0xFFE4EDF0.toInt())
        }
        elevation = dp(2).toFloat()
        val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(6)
        layoutParams = lp
    }

    private fun actionButton(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false; setTextColor(0xFFFFFFFF.toInt())
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(color); cornerRadius = dp(13).toFloat()
        }
        setPadding(dp(4), 0, dp(4), 0)
        setOnClickListener { action() }
    }

    private fun sectionText(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(7), 0, dp(7)); text = "در حال دریافت اطلاعات..."
    }

    private fun addHeading(label: String) {
        content.addView(TextView(this).apply {
            text = label; textSize = 16f; setTextColor(0xFF176F86.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(3), dp(16), dp(3), dp(8))
        })
    }

    private fun loadWeather() {
        loadMultiModelAnalysis()
        mainWeather.text = "در حال دریافت وضعیت هوا..."
        executor.execute {
            try {
                val weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m&hourly=temperature_2m,precipitation_probability,uv_index,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_sum&past_days=7&forecast_days=16&timezone=auto"
                val w = JSONObject(getUrl(weatherUrl))
                val current = w.getJSONObject("current")
                val currentLocationDate = runCatching { LocalDate.parse(current.optString("time", "").take(10)) }.getOrDefault(LocalDate.now())
                val airUrl = "https://air-quality-api.open-meteo.com/v1/air-quality?latitude=$latitude&longitude=$longitude&current=pm10,pm2_5,us_aqi,european_aqi&timezone=auto"
                val a = try { JSONObject(getUrl(airUrl)).optJSONObject("current") ?: JSONObject() } catch (_: Exception) { JSONObject() }
                val temp = current.optDouble("temperature_2m", Double.NaN)
                val feels = current.optDouble("apparent_temperature", Double.NaN)
                val humidity = current.optInt("relative_humidity_2m", -1)
                val wind = current.optDouble("wind_speed_10m", Double.NaN)
                val windDirection = current.optDouble("wind_direction_10m", Double.NaN)
                val windGust = current.optDouble("wind_gusts_10m", Double.NaN)
                val windText = "سرعت باد ${format(wind)} km/h · جهت ${windDirectionText(windDirection)}\nتندباد ${format(windGust)} km/h · مقیاس بوفورت ${beaufort(wind)}"
                val code = current.optInt("weather_code", -1)
                val hourlyData = w.optJSONObject("hourly") ?: JSONObject()
                val dailyData = w.optJSONObject("daily") ?: JSONObject()
                val hTimes = hourlyData.optJSONArray("time")
                val hTemps = hourlyData.optJSONArray("temperature_2m")
                val hRain = hourlyData.optJSONArray("precipitation_probability")
                val hCodes = hourlyData.optJSONArray("weather_code")
                val hWind = hourlyData.optJSONArray("wind_speed_10m")
                val hWindDir = hourlyData.optJSONArray("wind_direction_10m")
                val hWindGust = hourlyData.optJSONArray("wind_gusts_10m")
                val dCodes = dailyData.optJSONArray("weather_code")
                val dTimes = dailyData.optJSONArray("time")
                val dMax = dailyData.optJSONArray("temperature_2m_max")
                val dMin = dailyData.optJSONArray("temperature_2m_min")
                val dUv = dailyData.optJSONArray("uv_index_max")
                val dRain = dailyData.optJSONArray("precipitation_sum")
                val dSunrise = dailyData.optJSONArray("sunrise")
                val dSunset = dailyData.optJSONArray("sunset")
                val currentHour = current.optString("time", "").take(13)
                val firstHour = if (hTimes != null) (0 until hTimes.length()).firstOrNull { hTimes.optString(it).take(13) >= currentHour } ?: 0 else 0
                val hourText = buildString {
                    if (hTimes != null && hTemps != null) for (i in firstHour until minOf(firstHour + 6, hTimes.length(), hTemps.length())) {
                        val time = hTimes.optString(i).substringAfter('T')
                        val hourCode = hCodes?.optInt(i, code) ?: code
                        append("${weatherSticker(hourCode, true)}  $time  ${hTemps.optDouble(i).toInt()}°")
                        if (hRain != null) append("  احتمال بارش ${hRain.optInt(i)}٪")
                        if (hWind != null) append("  باد ${format(hWind.optDouble(i, Double.NaN))} km/h")
                        if (hWindDir != null) append(" ${windDirectionText(hWindDir.optDouble(i, Double.NaN))}")
                        if (hWindGust != null) append(" · تندباد ${format(hWindGust.optDouble(i, Double.NaN))} km/h")
                        append("\n")
                    }
                }
                val upcomingDayIndexes = if (dTimes != null) (0 until dTimes.length()).filter { index ->
                    runCatching { !LocalDate.parse(dTimes.optString(index)).isBefore(currentLocationDate) }.getOrDefault(false)
                }.take(7) else emptyList()
                val todayDailyIndex = upcomingDayIndexes.firstOrNull() ?: 0
                val dayText = buildString {
                    if (dTimes != null && dMax != null && dMin != null) for (i in upcomingDayIndexes) {
                        if (i >= dMax.length() || i >= dMin.length()) continue
                        val dayCode = dCodes?.optInt(i, -1) ?: -1
                        append("${weatherSticker(dayCode, true)}  ${dTimes.optString(i)}   بیشینه ${dMax.optDouble(i).toInt()}° / کمینه ${dMin.optDouble(i).toInt()}°")
                        if (dUv != null && i < dUv.length()) append("   UV ${dUv.optDouble(i).toInt()}")
                        if (dRain != null && i < dRain.length()) append("   بارش ${formatMm(dRain.optDouble(i, Double.NaN))} mm")
                        if (i == todayDailyIndex && dSunrise != null && dSunset != null && i < dSunrise.length() && i < dSunset.length()) {
                            append("\nطلوع ${dSunrise.optString(i).substringAfter('T')} · غروب ${dSunset.optString(i).substringAfter('T')}")
                        }
                        append("\n")
                    }
                }
                val aqi = a.optDouble("us_aqi", Double.NaN)
                val uvToday = if (dUv != null && todayDailyIndex < dUv.length()) dUv.optDouble(todayDailyIndex) else Double.NaN
                val airText = "کیفیت هوا: ${aqiDescription(aqi)}\nشاخص آمریکا AQI: ${format(aqi)}\nشاخص اروپا: ${format(a.optDouble("european_aqi", Double.NaN))}\nذرات PM2.5: ${format(a.optDouble("pm2_5", Double.NaN))} µg/m³\nذرات PM10: ${format(a.optDouble("pm10", Double.NaN))} µg/m³\nشاخص UV امروز: ${format(uvToday)} · ${uvDescription(uvToday)}"
                val isDay = current.optInt("is_day", 1) == 1
                val currentText = "${weatherSticker(code, isDay)}  ${format(temp)}°  ${weatherDescription(code)}"
                val detailsText = "احساس‌شده ${format(feels)}°   |   رطوبت ${if (humidity >= 0) "$humidity٪" else "--"}\n$windText"
                getSharedPreferences("weather", MODE_PRIVATE).edit()
                    .putString("temp", "${format(temp)}°")
                    .putString("description", weatherDescription(code))
                    .putInt("weather_code", code)
                    .putBoolean("is_day", isDay)
                    .putString("details", "رطوبت ${if (humidity >= 0) "$humidity٪" else "--"} · ${format(wind)} km/h ${windDirectionText(windDirection)} · تندباد ${format(windGust)} km/h · بوفورت ${beaufort(wind)}")
                    .putString("widget_hourly", hourText.trim())
                    .putString("widget_daily", dayText.trim())
                    .putString("widget_high_low", if (dMax != null && dMin != null && todayDailyIndex < dMax.length() && todayDailyIndex < dMin.length()) "بیشینه ${dMax.optDouble(todayDailyIndex).toInt()}°  ·  کمینه ${dMin.optDouble(todayDailyIndex).toInt()}°" else "")
                    .putString("aqi", format(a.optDouble("us_aqi", Double.NaN)))
                    .putString("pm25", format(a.optDouble("pm2_5", Double.NaN)))
                    .putString("uv", if (dUv != null && todayDailyIndex < dUv.length()) dUv.optDouble(todayDailyIndex).toInt().toString() else "--")
                    .putString("updated", java.text.SimpleDateFormat("HH:mm", Locale.getDefault()).format(java.util.Date()))
                    .putString("city", city).putString("lat", latitude.toString()).putString("lon", longitude.toString()).apply()
                runOnUiThread {
                    locationToday = currentLocationDate
                    cityTitle.text = city
                    mainWeather.text = currentText
                    (content.findViewWithTag<TextView>("weather_sticker"))?.text = weatherSticker(code, isDay)
                    details.text = "$detailsText\nآخرین به‌روزرسانی: ${java.text.SimpleDateFormat("HH:mm", Locale.getDefault()).format(java.util.Date())}"
                    hourly.text = hourText.ifBlank { "اطلاعات ساعتی در دسترس نیست" }
                    daily.text = dayText.ifBlank { "اطلاعات روزانه در دسترس نیست" }
                    air.text = airText
                    sendBroadcast(Intent("com.example.havapeyma.UPDATE_WIDGET").setPackage(packageName))
                }
            } catch (e: Exception) {
                runOnUiThread { mainWeather.text = "دریافت اطلاعات ناموفق بود"; details.text = "اتصال اینترنت را بررسی کنید و دوباره برنامه را باز کنید.\n${e.message ?: "خطای شبکه"}" }
            }
        }
    }

    /** Multi-model daily analysis. Every forecast date is independently selectable. */
    private fun loadMultiModelAnalysis() {
        multiModel.text = "در حال دریافت پیش‌بینی و مقایسه مدل‌های ECMWF، GFS و ICON..."
        selectedDayAnalysis.text = "در حال دریافت تحلیل روزهای آینده و بارندگی سال کشاورزی..."
        val lat = latitude
        val lon = longitude
        val selectedCity = city
        executor.execute {
            try {
                val modelSpecs = listOf(
                    "ecmwf_ifs" to "ECMWF اروپا",
                    "ncep_gfs_seamless" to "GFS آمریکا",
                    "icon_seamless" to "ICON آلمان"
                )
                val forecasts = mutableListOf<ModelForecast>()
                val failures = mutableListOf<String>()
                for ((model, label) in modelSpecs) {
                    try {
                        val address = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&models=$model&hourly=temperature_2m,precipitation_probability,precipitation,wind_speed_10m,wind_gusts_10m&forecast_days=7&timezone=auto"
                        val json = JSONObject(getUrl(address))
                        if (json.optBoolean("error", false)) throw Exception(json.optString("reason", "خطای API"))
                        val hourlyData = json.optJSONObject("hourly") ?: throw Exception("داده ساعتی موجود نیست")
                        val times = hourlyData.optJSONArray("time") ?: throw Exception("آرایه زمان موجود نیست")
                        val temps = hourlyData.optJSONArray("temperature_2m") ?: throw Exception("داده دما موجود نیست")
                        if (times.length() == 0 || temps.length() == 0) throw Exception("داده پیش‌بینی خالی است")
                        forecasts.add(ModelForecast(label, times, temps,
                            hourlyData.optJSONArray("precipitation_probability") ?: org.json.JSONArray(),
                            hourlyData.optJSONArray("precipitation") ?: org.json.JSONArray(),
                            hourlyData.optJSONArray("wind_speed_10m") ?: org.json.JSONArray(),
                            hourlyData.optJSONArray("wind_gusts_10m") ?: org.json.JSONArray()))
                    } catch (e: Exception) { failures.add("$label: ${e.message ?: "ناموفق"}") }
                }
                if (forecasts.isEmpty()) throw Exception("هیچ مدلی پاسخ معتبر نداد. ${failures.joinToString("؛ ")}")

                fun valid(array: org.json.JSONArray, index: Int): Double? =
                    array.optDouble(index).takeUnless { it.isNaN() || it.isInfinite() }
                val dates = forecasts.flatMap { f ->
                    (0 until f.times.length()).map { f.times.optString(it).take(10) }
                }.filter { it.length() == 10 }.distinct().sorted().take(7)
                val dayMap = linkedMapOf<String, DayForecast>()
                for (date in dates) {
                    val timesByModel = forecasts.map { f ->
                        (0 until f.times.length()).map { f.times.optString(it) }.filter { it.startsWith(date) }.toSet()
                    }
                    val commonTimes = timesByModel.first().filter { t -> timesByModel.all { it.contains(t) } }.sorted()
                    val useTimes = if (commonTimes.isNotEmpty()) commonTimes else timesByModel.first().sorted()
                    if (useTimes.isEmpty()) continue
                    fun valuesAt(time: String, selector: (ModelForecast) -> org.json.JSONArray): List<Double> =
                        forecasts.mapNotNull { f ->
                            val idx = f.timesIndex(time)
                            if (idx < 0) null else valid(selector(f), idx)
                        }
                    val tempHourly = useTimes.map { valuesAt(it) { f -> f.temps }.average() }.filterNot { it.isNaN() }
                    val rainProbHourly = useTimes.map { valuesAt(it) { f -> f.rainProb }.average() }.filterNot { it.isNaN() }
                    val rainHourly = useTimes.map { valuesAt(it) { f -> f.rain }.average() }.filterNot { it.isNaN() }
                    val windHourly = useTimes.map { valuesAt(it) { f -> f.wind }.average() }.filterNot { it.isNaN() }
                    val gustHourly = useTimes.map { valuesAt(it) { f -> f.gust }.average() }.filterNot { it.isNaN() }
                    val spreadHourly = useTimes.map { time ->
                        val vals = valuesAt(time) { f -> f.temps }
                        if (vals.size < 2) Double.NaN else vals.max() - vals.min()
                    }.filterNot { it.isNaN() }
                    val modelLines = forecasts.mapNotNull { f ->
                        val vals = useTimes.mapNotNull { t -> val i = f.timesIndex(t); if (i < 0) null else valid(f.temps, i) }
                        if (vals.isEmpty()) null else "• ${f.name}: میانگین ${format(vals.average())}°C"
                    }
                    val spread = spreadHourly.maxOrNull() ?: Double.NaN
                    val confidence = when {
                        forecasts.size == 1 -> "محدود؛ فقط یک مدل در دسترس است"
                        spread.isNaN() -> "نامشخص؛ داده هم‌زمان کافی نیست"
                        spread <= 2.0 -> "خوب؛ اختلاف دمای مدل‌ها کم است"
                        spread <= 4.0 -> "متوسط؛ بین مدل‌ها اختلاف وجود دارد"
                        else -> "پایین؛ اختلاف مدل‌ها قابل‌توجه است"
                    }
                    dayMap[date] = DayForecast(
                        date = date,
                        meanTemp = tempHourly.average(),
                        minTemp = tempHourly.minOrNull() ?: Double.NaN,
                        maxTemp = tempHourly.maxOrNull() ?: Double.NaN,
                        meanRainProb = rainProbHourly.average(),
                        totalRain = if (rainHourly.isEmpty()) Double.NaN else rainHourly.sum(),
                        maxWind = windHourly.maxOrNull() ?: Double.NaN,
                        maxGust = gustHourly.maxOrNull() ?: Double.NaN,
                        maxSpread = spread,
                        confidence = confidence,
                        modelLines = modelLines
                    )
                }
                if (dayMap.isEmpty()) throw Exception("روز قابل تحلیلی از پاسخ مدل‌ها دریافت نشد")
                val annual = fetchAgriculturalYearRainfall(lat, lon)
                val defaultDate = dayMap.keys.firstOrNull { runCatching { LocalDate.parse(it).isAfter(LocalDate.now()) }.getOrDefault(false) }
                    ?: dayMap.keys.first()
                runOnUiThread {
                    if (city == selectedCity && latitude == lat && longitude == lon) {
                        dailyAnalyses = dayMap
                        annualRainfall = annual
                        selectedForecastDate = if (dayMap.containsKey(selectedForecastDate)) selectedForecastDate else defaultDate
                        renderForecastDayButtons()
                        updateSelectedDayAnalysis()
                        val summary = buildString {
                            append("تحلیل چندمدلی برای $selectedCity\n")
                            append("روزهای قابل انتخاب: ${dayMap.size} روز\n")
                            append("مدل‌های موفق: ${forecasts.joinToString("، ") { it.name }}\n")
                            if (failures.isNotEmpty()) append("مدل‌های ناموفق: ${failures.joinToString("؛ ")}\n")
                            append("برای مشاهده جزئیات، تاریخ هر روز را از نوار انتخاب روزها لمس کنید.")
                        }
                        multiModel.text = summary
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (city == selectedCity && latitude == lat && longitude == lon) {
                        multiModel.text = "تحلیل هواشناسی دریافت نشد.\n${e.message ?: "خطای نامشخص"}\nاتصال اینترنت را بررسی و دوباره تلاش کنید."
                        selectedDayAnalysis.text = "تحلیل روزانه در دسترس نیست."
                    }
                }
            }
        }
    }

    private fun renderForecastDayButtons() {
        forecastDayButtons.removeAllViews()
        dailyAnalyses.keys.forEach { date ->
            val selected = date == selectedForecastDate
            val label = runCatching {
                LocalDate.parse(date).format(DateTimeFormatter.ofPattern("EEE d MMM", Locale("fa")))
            }.getOrDefault(date)
            val button = actionButton(label, if (selected) 0xFF126782.toInt() else 0xFF6F8790.toInt()) {
                selectedForecastDate = date
                renderForecastDayButtons()
                updateSelectedDayAnalysis()
            }
            forecastDayButtons.addView(button, LinearLayout.LayoutParams(-2, dp(40)).apply {
                marginEnd = dp(6); topMargin = dp(3); bottomMargin = dp(3)
            })
        }
    }

    private fun updateSelectedDayAnalysis() {
        val day = dailyAnalyses[selectedForecastDate] ?: run {
            selectedDayAnalysis.text = "یک روز را انتخاب کنید تا تحلیل اختصاصی آن نمایش داده شود."
            return
        }
        val actual = annualRainfall
        val today = actual?.let { runCatching { LocalDate.parse(it.todayDate) }.getOrNull() } ?: locationToday
        val futureRain = dailyAnalyses.values.filter { item ->
            runCatching { val d = LocalDate.parse(item.date); !d.isBefore(today) && !d.isAfter(LocalDate.parse(day.date)) }.getOrDefault(false)
        }.sumOf { if (it.totalRain.isNaN()) 0.0 else it.totalRain }
        val agriText = if (actual == null) {
            "بارندگی سال کشاورزی: داده تاریخی معتبر در دسترس نیست؛ مجموع سالانه اعلام نمی‌شود."
        } else {
            val recentText = if (actual.recentEstimateMm.isNaN()) "" else "\nبرآورد موقت بارش روزهای اخیر تا امروز: ${formatMm(actual.recentEstimateMm)} mm"
            val projection = if (runCatching { LocalDate.parse(day.date).isAfter(today.minusDays(1)) }.getOrDefault(false)) {
                val estimatedTotalText = if (actual.recentEstimateMm.isNaN()) {
                    "برآورد کامل مجموع سالانه ممکن نیست؛ داده روزهای اخیر موجود نیست."
                } else {
                    "برآورد تجمعی سال کشاورزی تا تاریخ انتخابی: ${formatMm(actual.actualMm + actual.recentEstimateMm + futureRain)} mm"
                }
                "\nبارش پیش‌بینی‌شده از امروز تا تاریخ انتخابی: ${formatMm(futureRain)} mm\n$estimatedTotalText"
            } else ""
            "مجموع بارش آرشیوی سال کشاورزی (ERA5) از ۱ مهر تا ${actual.throughDate}: ${formatMm(actual.actualMm)} mm$recentText$projection\nتوجه: داده ERA5 بازتحلیل هواشناسی است، نه اندازه‌گیری مستقیم باران‌سنج؛ بارش روزهای اخیر و آینده نیز برآوردی است."
        }
        val rainText = when {
            day.meanRainProb >= 70 -> "احتمال بارندگی بالا است؛ برای فعالیت‌های بیرونی و گلخانه‌ای آماده باشید."
            day.meanRainProb >= 40 -> "احتمال بارش قابل توجه است؛ زمان و شدت بارش را با پیش‌بینی ساعتی بررسی کنید."
            day.meanRainProb >= 20 -> "احتمال بارندگی کم تا متوسط است."
            day.meanRainProb.isNaN() -> "احتمال بارش از داده‌های موجود قابل محاسبه نیست."
            else -> "احتمال بارش پایین است."
        }
        val windText = when {
            day.maxGust >= 60 -> "تندباد شدید محتمل است؛ سازه‌ها و پوشش گلخانه بررسی شوند."
            day.maxGust >= 40 -> "احتمال تندباد نسبتاً شدید وجود دارد."
            day.maxGust.isNaN() -> "داده تندباد موجود نیست."
            else -> "تندباد شدید در پیش‌بینی مدل‌ها دیده نمی‌شود."
        }
        selectedDayAnalysis.text = buildString {
            append("تحلیل اختصاصی $selectedForecastDate\n")
            append("دمای میانگین ${format(day.meanTemp)}°C · کمینه ${format(day.minTemp)}°C · بیشینه ${format(day.maxTemp)}°C\n")
            append("بارندگی روز: ${formatMm(day.totalRain)} mm · احتمال متوسط بارش: ${format(day.meanRainProb)}٪\n")
            append("بیشترین سرعت باد: ${format(day.maxWind)} km/h · تندباد: ${format(day.maxGust)} km/h\n")
            append("اختلاف دمای مدل‌ها: ${format(day.maxSpread)}°C · اطمینان: ${day.confidence}\n")
            append("تحلیل: $rainText $windText\n\n")
            append("${day.modelLines.joinToString("\n")}\n\n")
            append(agriText)
            if (actual == null) append("\nمبنای سال کشاورزی: ۱ مهر تا پایان شهریور؛ مجموع واقعی فقط در صورت دریافت داده تاریخی معتبر نمایش داده می‌شود.")
        }
    }

    private fun fetchAgriculturalYearRainfall(lat: Double, lon: Double): AnnualRainfall? {
        return try {
            val recentUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m&daily=precipitation_sum&past_days=7&forecast_days=1&timezone=auto"
            val recentJson = JSONObject(getUrl(recentUrl))
            val locationDate = recentJson.optJSONObject("current")?.optString("time", "")?.take(10)
            val today = runCatching { LocalDate.parse(locationDate) }.getOrElse { LocalDate.now() }
            val start = agriculturalYearStart(today)
            val archiveEnd = today.minusDays(8)
            var actualTotal = 0.0
            if (!archiveEnd.isBefore(start)) {
                val archiveUrl = "https://archive-api.open-meteo.com/v1/archive?latitude=$lat&longitude=$lon&start_date=$start&end_date=$archiveEnd&daily=precipitation_sum&timezone=auto"
                val archive = JSONObject(getUrl(archiveUrl))
                val daily = archive.optJSONObject("daily") ?: throw Exception("داده تاریخی بارندگی موجود نیست")
                val values = daily.optJSONArray("precipitation_sum") ?: throw Exception("آرایه بارندگی تاریخی موجود نیست")
                for (i in 0 until values.length()) {
                    val value = values.optDouble(i, Double.NaN)
                    if (!value.isNaN() && !value.isInfinite()) actualTotal += value
                }
            }
            var recentEstimate = 0.0
            var recentAvailable = false
            try {
                val recentDaily = recentJson.optJSONObject("daily") ?: throw Exception("داده روزهای اخیر موجود نیست")
                val times = recentDaily.optJSONArray("time") ?: throw Exception("تاریخ‌های روزهای اخیر موجود نیست")
                val values = recentDaily.optJSONArray("precipitation_sum") ?: throw Exception("مقادیر بارندگی روزهای اخیر موجود نیست")
                for (i in 0 until minOf(times.length(), values.length())) {
                    val date = runCatching { LocalDate.parse(times.optString(i)) }.getOrNull() ?: continue
                    if (date.isAfter(archiveEnd) && date.isBefore(today) && !date.isBefore(start)) {
                        val value = values.optDouble(i, Double.NaN)
                        if (!value.isNaN() && !value.isInfinite()) { recentEstimate += value; recentAvailable = true }
                    }
                }
            } catch (_: Exception) { }
            AnnualRainfall(actualTotal, start.toString(), archiveEnd.toString(), if (recentAvailable) recentEstimate else Double.NaN, today.toString())
        } catch (_: Exception) { null }
    }

    private fun agriculturalYearStart(today: LocalDate): LocalDate {
        val persian = PersianCalendar(android.icu.util.TimeZone.getTimeZone("UTC"), Locale("fa"))
        persian.timeInMillis = today.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val currentYear = persian.get(PersianCalendar.YEAR)
        val currentMonth = persian.get(PersianCalendar.MONTH)
        val agriculturalYear = if (currentMonth >= 6) currentYear else currentYear - 1
        persian.clear()
        persian.set(PersianCalendar.YEAR, agriculturalYear)
        persian.set(PersianCalendar.MONTH, 6) // Mehr
        persian.set(PersianCalendar.DAY_OF_MONTH, 1)
        persian.set(PersianCalendar.HOUR_OF_DAY, 0)
        return Instant.ofEpochMilli(persian.timeInMillis).atZone(ZoneOffset.UTC).toLocalDate()
    }

    private data class DayForecast(
        val date: String, val meanTemp: Double, val minTemp: Double, val maxTemp: Double,
        val meanRainProb: Double, val totalRain: Double, val maxWind: Double, val maxGust: Double,
        val maxSpread: Double, val confidence: String, val modelLines: List<String>
    )
    private data class AnnualRainfall(val actualMm: Double, val startDate: String, val throughDate: String, val recentEstimateMm: Double, val todayDate: String)

    private data class ModelForecast(
        val name: String,
        val times: org.json.JSONArray,
        val temps: org.json.JSONArray,
        val rainProb: org.json.JSONArray,
        val rain: org.json.JSONArray,
        val wind: org.json.JSONArray,
        val gust: org.json.JSONArray
    ) {
        fun timesIndex(time: String): Int = (0 until times.length()).firstOrNull { times.optString(it) == time } ?: -1
    }

    private fun aqiDescription(value: Double): String = when {
        value.isNaN() -> "نامشخص"
        value <= 50 -> "پاک و مناسب"
        value <= 100 -> "متوسط"
        value <= 150 -> "ناسالم برای گروه‌های حساس"
        value <= 200 -> "ناسالم"
        value <= 300 -> "بسیار ناسالم"
        else -> "خطرناک"
    }

    private fun uvDescription(value: Double): String = when {
        value.isNaN() -> "نامشخص"
        value < 3 -> "کم"
        value < 6 -> "متوسط"
        value < 8 -> "زیاد"
        value < 11 -> "خیلی زیاد"
        else -> "شدید"
    }

    private fun format(value: Double): String = if (value.isNaN() || value.isInfinite()) "--" else String.format(Locale.US, "%.0f", value)
    private fun formatMm(value: Double): String = if (value.isNaN() || value.isInfinite()) "--" else String.format(Locale.US, "%.1f", value)

    private fun getUrl(address: String): String {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 20000; connection.readTimeout = 25000; connection.requestMethod = "GET"
        connection.setRequestProperty("Accept", "application/json")
        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw Exception("HTTP $code: ${body.take(300)}")
            body
        } finally { connection.disconnect() }
    }

    private fun weatherDescription(code: Int): String = when (code) {
        0 -> "آسمان صاف"; 1 -> "عمدتاً صاف"; 2 -> "نیمه‌ابری"; 3 -> "ابری"
        45, 48 -> "مه‌آلود"; 51, 53, 55 -> "نم‌نم باران"; 56, 57 -> "باران یخ‌زن"
        61, 63, 65 -> "بارانی"; 66, 67 -> "باران یخ‌زن"; 71, 73, 75, 77 -> "برفی"
        80, 81, 82 -> "رگبار باران"; 85, 86 -> "رگبار برف"; 95, 96, 99 -> "رعدوبرق"; else -> "وضعیت نامشخص"
    }

    private fun showMapPicker() {
        var selectedLat = latitude
        var selectedLon = longitude
        val webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webViewClient = WebViewClient()
        }
        val status = TextView(this).apply {
            text = "نقطه فعلی: ${"%.5f".format(Locale.US, selectedLat)}, ${"%.5f".format(Locale.US, selectedLon)}\nروی نقشه لمس کنید تا نقطه جابه‌جا شود."
            textSize = 14f
            setTextColor(0xFF254653.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun pointChanged(lat: Double, lon: Double) {
                selectedLat = lat
                selectedLon = lon
                runOnUiThread {
                    status.text = "نقطه انتخابی: ${"%.5f".format(Locale.US, lat)}, ${"%.5f".format(Locale.US, lon)}\nبرای ثبت، دکمه «انتخاب این نقطه» را بزنید."
                }
            }
        }, "MapBridge")

        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(webView, LinearLayout.LayoutParams(-1, dp(430)))
            addView(status, LinearLayout.LayoutParams(-1, -2))
        }
        val html = """<!DOCTYPE html><html lang="fa"><head><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"><link href="https://unpkg.com/maplibre-gl@5.6.0/dist/maplibre-gl.css" rel="stylesheet"><style>html,body,#map{height:100%;width:100%;margin:0;padding:0}body{font-family:sans-serif}.maplibregl-ctrl-attrib{font-size:11px}</style></head><body><div id="map"></div><script src="https://unpkg.com/maplibre-gl@5.6.0/dist/maplibre-gl.js"></script><script>const lat=$selectedLat,lon=$selectedLon;const map=new maplibregl.Map({container:'map',style:'https://tiles.openfreemap.org/styles/liberty',center:[lon,lat],zoom:10,attributionControl:true});let marker=new maplibregl.Marker({draggable:true}).setLngLat([lon,lat]).addTo(map);marker.on('dragend',function(){const p=marker.getLngLat();MapBridge.pointChanged(p.lat,p.lng);});map.on('click',function(e){marker.setLngLat(e.lngLat);MapBridge.pointChanged(e.lngLat.lat,e.lngLat.lng);});</script></body></html>"""
        webView.loadDataWithBaseURL("https://openfreemap.org/", html, "text/html", "UTF-8", null)
        val dialog = AlertDialog.Builder(this)
            .setTitle("انتخاب نقطه هواشناسی")
            .setView(holder)
            .setPositiveButton("انتخاب این نقطه") { _, _ ->
                latitude = selectedLat
                longitude = selectedLon
                city = "نقطه نقشه (${"%.4f".format(Locale.US, latitude)}, ${"%.4f".format(Locale.US, longitude)})"
                applySelectedCity(city, latitude, longitude)
            }
            .setNegativeButton("انصراف", null)
            .create()
        dialog.setOnDismissListener { webView.destroy() }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.96).toInt(), (resources.displayMetrics.heightPixels * 0.88).toInt())
    }

    private fun showCitySearch() {
        val input = EditText(this).apply { hint = "نام شهر؛ مانند شیراز یا صفاشهر"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("جست‌وجوی شهر")
            .setMessage("نام شهر را وارد کنید؛ سپس از میان نتایج، شهر درست را انتخاب کنید.")
            .setView(input)
            .setPositiveButton("جست‌وجو") { _, _ -> searchCity(input.text.toString().trim()) }
            .setNegativeButton("انصراف", null).show()
    }

    private fun searchCity(query: String) {
        if (query.isBlank()) return
        Toast.makeText(this, "در حال جست‌وجوی شهرها...", Toast.LENGTH_SHORT).show()
        executor.execute {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val json = JSONObject(getUrl("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=12&language=fa&format=json"))
                val results = json.optJSONArray("results")
                if (results == null || results.length() == 0) throw Exception("شهری با این نام پیدا نشد")
                val items = (0 until results.length()).mapNotNull { results.optJSONObject(it) }
                val labels = items.map { item ->
                    listOf(item.optString("name"), item.optString("admin1"), item.optString("country")).filter { it.isNotBlank() }.distinct().joinToString("، ")
                }.toTypedArray()
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("انتخاب شهر صحیح")
                        .setItems(labels) { _, which ->
                            val item = items[which]
                            val name = listOf(item.optString("name", query), item.optString("admin1"), item.optString("country"))
                                .filter { it.isNotBlank() }.distinct().joinToString("، ")
                            applySelectedCity(name, item.getDouble("latitude"), item.getDouble("longitude"))
                        }
                        .setNegativeButton("انصراف", null).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, e.message ?: "خطا در جست‌وجوی شهر", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun applySelectedCity(name: String, lat: Double, lon: Double) {
        city = name
        latitude = lat
        longitude = lon
        val prefs = getSharedPreferences("weather", MODE_PRIVATE)
        val saved = try { org.json.JSONArray(prefs.getString("saved_cities", "[]") ?: "[]") } catch (_: Exception) { org.json.JSONArray() }
        val updated = org.json.JSONArray()
        var found = false
        for (i in 0 until saved.length()) {
            val item = saved.optJSONObject(i) ?: continue
            if (item.optString("name").equals(name, true)) {
                updated.put(JSONObject().put("name", name).put("lat", lat).put("lon", lon)); found = true
            } else updated.put(item)
        }
        if (!found) updated.put(JSONObject().put("name", name).put("lat", lat).put("lon", lon))
        prefs.edit().putString("city", name).putString("lat", lat.toString()).putString("lon", lon.toString())
            .putString("saved_cities", updated.toString()).apply()
        cityTitle.text = name
        syncWidgetCities(name)
        loadWeather()
        Toast.makeText(this, "شهر $name انتخاب شد", Toast.LENGTH_SHORT).show()
    }

    private fun syncWidgetCities(name: String) {
        val manager = android.appwidget.AppWidgetManager.getInstance(this)
        val prefs = getSharedPreferences("weather", MODE_PRIVATE).edit()
        val providers = listOf(SmallWeatherWidgetProvider::class.java, MediumWeatherWidgetProvider::class.java, LargeWeatherWidgetProvider::class.java)
        providers.forEach { provider ->
            manager.getAppWidgetIds(android.content.ComponentName(this, provider)).forEach { id ->
                prefs.putString("widget_city_name_$id", name)
            }
        }
        prefs.apply()
        sendBroadcast(Intent(WeatherWidgetProvider.ACTION_UPDATE_WIDGET).setPackage(packageName))
    }

    private fun appRefreshIntervalMs(): Long {
        val minutes = getSharedPreferences("weather", MODE_PRIVATE).getInt("app_refresh_minutes", 30).coerceIn(15, 360)
        return minutes * 60L * 1000L
    }

    private fun showUpdateSettings() {
        val prefs = getSharedPreferences("weather", MODE_PRIVATE)
        val appOptions = arrayOf("۱۵ دقیقه", "۳۰ دقیقه", "۱ ساعت", "۲ ساعت", "۴ ساعت")
        val appValues = intArrayOf(15, 30, 60, 120, 240)
        val widgetOptions = arrayOf("۱۵ دقیقه", "۳۰ دقیقه", "۱ ساعت", "۳ ساعت", "۶ ساعت")
        val widgetValues = intArrayOf(15, 30, 60, 180, 360)
        val appSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, appOptions)
            setSelection(appValues.indexOf(prefs.getInt("app_refresh_minutes", 30)).coerceAtLeast(0))
        }
        val widgetSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, widgetOptions)
            setSelection(widgetValues.indexOf(prefs.getInt("widget_refresh_minutes", 30)).coerceAtLeast(0))
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), dp(8))
            addView(TextView(this@MainActivity).apply { text = "فاصله به‌روزرسانی برنامه (هنگام باز بودن)"; textSize = 14f; setTextColor(0xFF254653.toInt()) })
            addView(appSpinner, LinearLayout.LayoutParams(-1, dp(52)))
            addView(TextView(this@MainActivity).apply { text = "فاصله به‌روزرسانی ویجت‌ها"; textSize = 14f; setTextColor(0xFF254653.toInt()); setPadding(0, dp(12), 0, 0) })
            addView(widgetSpinner, LinearLayout.LayoutParams(-1, dp(52)))
            addView(TextView(this@MainActivity).apply { text = "برنامه در حالت باز با فاصله انتخابی تازه می‌شود؛ ویجت با زمان‌بندی پس‌زمینه به‌روزرسانی می‌شود. حداقل فاصله ویجت ۱۵ دقیقه است و مدیریت باتری اندروید ممکن است زمان اجرا را کمی جابه‌جا کند."; textSize = 11f; setTextColor(0xFF71858D.toInt()); setPadding(0, dp(8), 0, 0) })
        }
        AlertDialog.Builder(this).setTitle("تنظیم زمان به‌روزرسانی")
            .setView(panel)
            .setPositiveButton("ذخیره") { _, _ ->
                val appMinutes = appValues[appSpinner.selectedItemPosition]
                val widgetMinutes = widgetValues[widgetSpinner.selectedItemPosition]
                prefs.edit().putInt("app_refresh_minutes", appMinutes).putInt("widget_refresh_minutes", widgetMinutes).apply()
                WidgetRefreshScheduler.schedule(this)
                refreshHandler.removeCallbacks(automaticRefresh)
                refreshHandler.postDelayed(automaticRefresh, appRefreshIntervalMs())
                Toast.makeText(this, "تنظیمات به‌روزرسانی ذخیره شد", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("انصراف", null).show()
    }

    private fun saveCurrentCity() {
        val prefs = getSharedPreferences("weather", MODE_PRIVATE)
        val list = try { org.json.JSONArray(prefs.getString("saved_cities", "[]") ?: "[]") } catch (_: Exception) { org.json.JSONArray() }
        val updated = org.json.JSONArray()
        var replaced = false
        for (i in 0 until list.length()) {
            val item = list.optJSONObject(i) ?: continue
            if (item.optString("name").equals(city, true)) {
                updated.put(JSONObject().put("name", city).put("lat", latitude).put("lon", longitude)); replaced = true
            } else updated.put(item)
        }
        if (!replaced) updated.put(JSONObject().put("name", city).put("lat", latitude).put("lon", longitude))
        prefs.edit().putString("saved_cities", updated.toString()).apply()
        sendBroadcast(Intent(WeatherWidgetProvider.ACTION_UPDATE_WIDGET).setPackage(packageName))
        Toast.makeText(this, "شهر «$city» ذخیره شد", Toast.LENGTH_SHORT).show()
    }

    private fun showSavedCities() {
        val prefs = getSharedPreferences("weather", MODE_PRIVATE)
        val list = try { org.json.JSONArray(prefs.getString("saved_cities", "[]") ?: "[]") } catch (_: Exception) { org.json.JSONArray() }
        val names = ArrayList<String>()
        for (i in 0 until list.length()) names.add(list.optJSONObject(i)?.optString("name") ?: "")
        if (names.isEmpty()) {
            AlertDialog.Builder(this).setTitle("شهرهای ذخیره‌شده")
                .setMessage("هنوز شهری ذخیره نشده است. ابتدا شهر را جست‌وجو یا با GPS انتخاب کنید، سپس گزینه «ذخیره شهر فعلی» را بزنید.")
                .setPositiveButton("متوجه شدم", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("انتخاب شهر ذخیره‌شده")
            .setItems(names.toTypedArray()) { _, which ->
                val item = list.optJSONObject(which) ?: return@setItems
                applySelectedCity(item.optString("name", "شهر"), item.optDouble("lat", latitude), item.optDouble("lon", longitude))
            }
            .setNeutralButton("ذخیره شهر فعلی") { _, _ -> saveCurrentCity() }
            .setNegativeButton("بستن", null).show()
    }

    private fun weatherSticker(code: Int, isDay: Boolean): String = when (code) {
        0 -> if (isDay) "☀️" else "🌙"
        1 -> if (isDay) "🌤️" else "🌙☁️"
        2 -> "⛅"; 3 -> "☁️"
        45, 48 -> "🌫️"
        51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> "🌧️"
        71, 73, 75, 77, 85, 86 -> "❄️"
        95, 96, 99 -> "⛈️"
        else -> "🌡️"
    }

    private fun requestGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 41); return
        }
        try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            val location: Location? = manager.getProviders(true).asSequence().mapNotNull { provider -> try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null } }.maxByOrNull { it.time }
            if (location == null) { Toast.makeText(this, "موقعیت در دسترس نیست؛ GPS را روشن کنید یا شهر را جست‌وجو کنید.", Toast.LENGTH_LONG).show(); return }
            applySelectedCity("موقعیت من", location.latitude, location.longitude)
        } catch (_: SecurityException) { Toast.makeText(this, "اجازه مکان‌یابی داده نشد", Toast.LENGTH_SHORT).show() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) requestGps()
        else if (requestCode == 41) Toast.makeText(this, "برای استفاده از GPS باید اجازه مکان‌یابی بدهید.", Toast.LENGTH_LONG).show()
    }
    private fun windDirectionText(degrees: Double): String {
        if (degrees.isNaN() || degrees.isInfinite()) return "نامشخص"
        val directions = arrayOf("شمال", "شمال‌شرق", "شرق", "جنوب‌شرق", "جنوب", "جنوب‌غرب", "غرب", "شمال‌غرب")
        return directions[((degrees + 22.5) / 45.0).toInt() % 8] + " (${degrees.toInt()}°)"
    }

    private fun beaufort(speed: Double): Int = when {
        speed.isNaN() || speed < 0 -> 0
        speed < 1 -> 0; speed < 6 -> 1; speed < 12 -> 2; speed < 20 -> 3
        speed < 29 -> 4; speed < 39 -> 5; speed < 50 -> 6; speed < 62 -> 7
        speed < 75 -> 8; speed < 89 -> 9; speed < 103 -> 10; speed < 118 -> 11
        else -> 12
    }

    companion object {}

}


/** Inexact repeating alarm for widgets; Android may batch delivery to save battery. */
object WidgetRefreshScheduler {
    fun schedule(context: Context) {
        val minutes = context.getSharedPreferences("weather", Context.MODE_PRIVATE)
            .getInt("widget_refresh_minutes", 30).coerceIn(15, 360)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, WidgetRefreshReceiver::class.java).setAction(WidgetRefreshReceiver.ACTION_TICK)
        val pending = android.app.PendingIntent.getBroadcast(
            context, 7301, intent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        alarm.cancel(pending)
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + minutes * 60_000L,
            minutes * 60_000L, pending)
    }
}

class WidgetRefreshReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            WidgetRefreshScheduler.schedule(context)
            return
        }
        val update = Intent(WeatherWidgetProvider.ACTION_UPDATE_WIDGET).setPackage(context.packageName)
        context.sendBroadcast(update)
    }
    companion object { const val ACTION_TICK = "com.example.havapeyma.WIDGET_REFRESH_TICK" }
}

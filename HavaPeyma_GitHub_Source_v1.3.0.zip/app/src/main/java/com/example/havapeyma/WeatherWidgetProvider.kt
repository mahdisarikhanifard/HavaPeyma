package com.example.havapeyma

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

open class WeatherWidgetProvider : AppWidgetProvider() {
    protected open val widgetLayout: Int = R.layout.widget_small

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        refresh(context, manager, ids)
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
        render(context, manager, appWidgetId)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_UPDATE_WIDGET -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, javaClass))
                refresh(context, manager, ids)
            }
            ACTION_PREVIOUS_CITY, ACTION_NEXT_CITY -> {
                val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
                if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                    val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    val cities = cityList(context)
                    if (cities.isNotEmpty()) {
                        val key = cityNameKey(id)
                        val currentName = prefs.getString(key, null) ?: (prefs.getString("city", "لندن") ?: "لندن")
                        val old = cities.indexOfFirst { it.name.equals(currentName, true) }.let { if (it < 0) 0 else it }
                        val next = if (intent.action == ACTION_NEXT_CITY) (old + 1) % cities.size else (old - 1 + cities.size) % cities.size
                        prefs.edit().putString(key, cities[next].name).apply()
                        refresh(context, AppWidgetManager.getInstance(context), intArrayOf(id))
                    }
                }
            }
        }
    }

    private fun refresh(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            render(context, manager, id)
            val cities = cityList(context)
            if (cities.isEmpty()) return@forEach
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val currentName = prefs.getString(cityNameKey(id), null) ?: (prefs.getString("city", "لندن") ?: "لندن")
            val index = cities.indexOfFirst { it.name.equals(currentName, true) }.let { if (it < 0) 0 else it }
            val city = cities[index]
            prefs.edit().putString(cityNameKey(id), city.name).apply()
            EXECUTOR.execute { fetchAndStore(context, manager, id, city) }
        }
    }

    private fun cityList(context: Context): List<City> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val result = mutableListOf<City>()
        try {
            val saved = JSONArray(prefs.getString("saved_cities", "[]") ?: "[]")
            for (i in 0 until saved.length()) {
                val item = saved.optJSONObject(i) ?: continue
                val name = item.optString("name", "").trim()
                val lat = item.optString("lat", "").toDoubleOrNull()
                val lon = item.optString("lon", "").toDoubleOrNull()
                if (name.isNotBlank() && lat != null && lon != null && result.none { it.name.equals(name, true) }) {
                    result.add(City(name, lat, lon))
                }
            }
        } catch (_: Exception) { }
        val currentName = prefs.getString("city", "لندن") ?: "لندن"
        val currentLat = prefs.getString("lat", "51.5072")?.toDoubleOrNull() ?: 51.5072
        val currentLon = prefs.getString("lon", "-0.1276")?.toDoubleOrNull() ?: -0.1276
        if (result.none { it.name.equals(currentName, true) }) result.add(0, City(currentName, currentLat, currentLon))
        return result
    }

    private fun fetchAndStore(context: Context, manager: AppWidgetManager, id: Int, city: City) {
        val p = "widget_${id}_"
        try {
            val weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code,is_day&hourly=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,weather_code&forecast_days=5&timezone=auto"
            val w = JSONObject(getUrl(weatherUrl))
            val current = w.getJSONObject("current")
            val code = current.optInt("weather_code", -1)
            val isDay = current.optInt("is_day", 1) == 1
            val daily = w.optJSONObject("daily") ?: JSONObject()
            val max = daily.optJSONArray("temperature_2m_max")
            val min = daily.optJSONArray("temperature_2m_min")
            val dCodes = daily.optJSONArray("weather_code")
            val dTimes = daily.optJSONArray("time")
            val hourly = w.optJSONObject("hourly") ?: JSONObject()
            val hTimes = hourly.optJSONArray("time")
            val hTemps = hourly.optJSONArray("temperature_2m")
            val hCodes = hourly.optJSONArray("weather_code")
            val currentHour = current.optString("time", "").take(13)
            val firstHour = if (hTimes != null) (0 until hTimes.length()).firstOrNull { hTimes.optString(it).take(13) >= currentHour } ?: 0 else 0
            val hourlyText = buildString {
                if (hTimes != null && hTemps != null) for (i in firstHour until minOf(firstHour + 5, hTimes.length(), hTemps.length())) {
                    append("${sticker(hCodes?.optInt(i, code) ?: code)} ${hTimes.optString(i).substringAfter('T')} ${hTemps.optDouble(i).toInt()}°   ")
                }
            }.trim()
            val dailyText = buildString {
                if (dTimes != null && max != null && min != null) for (i in 0 until minOf(5, dTimes.length(), max.length(), min.length())) {
                    append("${sticker(dCodes?.optInt(i, -1) ?: -1)} ${dTimes.optString(i)}  ${max.optDouble(i).toInt()}°/${min.optDouble(i).toInt()}°\n")
                }
            }.trim()
            val air = try {
                val a = JSONObject(getUrl("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${city.lat}&longitude=${city.lon}&current=pm2_5,us_aqi&timezone=auto")).optJSONObject("current") ?: JSONObject()
                "AQI ${fmt(a.optDouble("us_aqi", Double.NaN))} · PM2.5 ${fmt(a.optDouble("pm2_5", Double.NaN))}"
            } catch (_: Exception) { "AQI -- · PM2.5 --" }
            val highLow = if (max != null && min != null && max.length() > 0 && min.length() > 0) "بیشینه ${max.optDouble(0).toInt()}° · کمینه ${min.optDouble(0).toInt()}°" else "بیشینه --° · کمینه --°"
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(p + "city", city.name)
                .putString(p + "temp", "${current.optDouble("temperature_2m").toInt()}°")
                .putString(p + "description", description(code))
                .putString(p + "details", "رطوبت ${current.optInt("relative_humidity_2m")}٪ · باد ${current.optDouble("wind_speed_10m").toInt()} km/h")
                .putString(p + "high_low", highLow)
                .putString(p + "hourly", hourlyText.ifBlank { "پیش‌بینی ساعتی موجود نیست" })
                .putString(p + "daily", dailyText.ifBlank { "پیش‌بینی روزانه موجود نیست" })
                .putString(p + "air", air)
                .putString(p + "updated", SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
                .putInt(p + "code", code).putBoolean(p + "is_day", isDay).apply()
            render(context, manager, id)
        } catch (_: Exception) {
            // Keep the last successful widget data when offline.
        }
    }

    private fun getUrl(url: String): String {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 12000
        connection.readTimeout = 12000
        return try { connection.inputStream.bufferedReader().use { it.readText() } } finally { connection.disconnect() }
    }

    private fun render(context: Context, manager: AppWidgetManager, id: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val p = "widget_${id}_"
        val views = RemoteViews(context.packageName, widgetLayout)
        val code = prefs.getInt(p + "code", -1)
        val isDay = prefs.getBoolean(p + "is_day", true)
        val cities = cityList(context)
        val defaultCityName = prefs.getString("city", "لندن") ?: "لندن"
        val selectedCityName = prefs.getString(cityNameKey(id), defaultCityName) ?: defaultCityName
        val cityName = prefs.getString(p + "city", selectedCityName) ?: selectedCityName
        views.setTextViewText(R.id.widget_city, cityName)
        views.setTextViewText(R.id.widget_temp, prefs.getString(p + "temp", "--°") ?: "--°")
        views.setTextViewText(R.id.widget_desc, "${sticker(code, isDay)}  ${prefs.getString(p + "description", "برای دریافت هوا برنامه را باز کنید") ?: ""}")
        views.setTextViewText(R.id.widget_sticker, sticker(code, isDay))
        views.setImageViewResource(R.id.widget_weather_bg, backgroundFor(code, isDay))
        views.setTextViewText(R.id.widget_details, prefs.getString(p + "details", "") ?: "")
        views.setTextViewText(R.id.widget_air, prefs.getString(p + "air", "AQI -- · PM2.5 --") ?: "")
        views.setTextViewText(R.id.widget_updated, "به‌روزرسانی ${prefs.getString(p + "updated", "--:--")}")
        if (widgetLayout == R.layout.widget_medium || widgetLayout == R.layout.widget_large) {
            views.setTextViewText(R.id.widget_high_low, prefs.getString(p + "high_low", "بیشینه --° · کمینه --°") ?: "")
        }
        if (widgetLayout == R.layout.widget_large) {
            views.setTextViewText(R.id.widget_forecast_hourly, prefs.getString(p + "hourly", "پیش‌بینی ساعتی پس از دریافت اطلاعات نمایش داده می‌شود") ?: "")
            views.setTextViewText(R.id.widget_forecast_daily, prefs.getString(p + "daily", "پیش‌بینی روزانه پس از دریافت اطلاعات نمایش داده می‌شود") ?: "")
        }
        val prev = Intent(context, javaClass).setAction(ACTION_PREVIOUS_CITY).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        val next = Intent(context, javaClass).setAction(ACTION_NEXT_CITY).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        views.setOnClickPendingIntent(R.id.widget_city_prev, PendingIntent.getBroadcast(context, id * 10 + 1, prev, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        views.setOnClickPendingIntent(R.id.widget_city_next, PendingIntent.getBroadcast(context, id * 10 + 2, next, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        if (launch != null) {
            val pending = PendingIntent.getActivity(context, id + 10000, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pending)
        }
        manager.updateAppWidget(id, views)
    }

    private fun backgroundFor(code: Int, isDay: Boolean): Int = when {
        code == 0 && isDay -> R.drawable.weather_bg_sunny
        code in 1..3 -> R.drawable.weather_bg_cloudy
        code == 45 || code == 48 -> R.drawable.weather_bg_fog
        code in 51..67 || code in 80..82 -> R.drawable.weather_bg_rain
        code in 71..77 || code in 85..86 -> R.drawable.weather_bg_snow
        code in 95..99 -> R.drawable.weather_bg_storm
        !isDay -> R.drawable.weather_bg_night
        else -> R.drawable.weather_bg_cloudy
    }

    private fun description(code: Int): String = when (code) {
        0 -> "آسمان صاف"; 1 -> "عمدتاً صاف"; 2 -> "نیمه‌ابری"; 3 -> "ابری"
        45, 48 -> "مه‌آلود"; in 51..57 -> "نم‌نم باران"; in 61..67 -> "بارانی"
        in 71..77 -> "برفی"; in 80..82 -> "رگبار"; in 85..86 -> "رگبار برف"
        in 95..99 -> "رعدوبرق"; else -> "وضعیت هوا"
    }

    private fun sticker(code: Int, isDay: Boolean = true): String = when (code) {
        0 -> if (isDay) "☀️" else "🌙"; 1 -> if (isDay) "🌤️" else "🌙☁️"
        2 -> "⛅"; 3 -> "☁️"; 45, 48 -> "🌫️"
        in 51..67, in 80..82 -> "🌧️"; in 71..77, in 85..86 -> "❄️"
        in 95..99 -> "⛈️"; else -> "🌡️"
    }

    private fun fmt(value: Double): String = if (value.isNaN()) "--" else value.toInt().toString()
    private fun cityNameKey(id: Int) = "widget_city_name_$id"
    private data class City(val name: String, val lat: Double, val lon: Double)

    companion object {
        private const val PREFS = "weather"
        const val ACTION_UPDATE_WIDGET = "com.example.havapeyma.UPDATE_WIDGET"
        private const val ACTION_PREVIOUS_CITY = "com.example.havapeyma.PREVIOUS_WIDGET_CITY"
        private const val ACTION_NEXT_CITY = "com.example.havapeyma.NEXT_WIDGET_CITY"
        private val EXECUTOR = Executors.newFixedThreadPool(3)
    }
}

class SmallWeatherWidgetProvider : WeatherWidgetProvider() {
    override val widgetLayout: Int = R.layout.widget_small
}
class MediumWeatherWidgetProvider : WeatherWidgetProvider() {
    override val widgetLayout: Int = R.layout.widget_medium
}
class LargeWeatherWidgetProvider : WeatherWidgetProvider() {
    override val widgetLayout: Int = R.layout.widget_large
}

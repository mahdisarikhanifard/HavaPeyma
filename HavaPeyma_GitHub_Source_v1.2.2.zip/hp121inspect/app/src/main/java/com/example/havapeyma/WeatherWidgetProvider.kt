package com.example.havapeyma

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

open class WeatherWidgetProvider : AppWidgetProvider() {
    protected open val widgetLayout: Int = R.layout.widget_small

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        refresh(context, manager, ids)
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
        render(context, manager, appWidgetId)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_UPDATE_WIDGET) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, javaClass))
            refresh(context, manager, ids)
        }
    }

    private fun refresh(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { render(context, manager, it) }
        if (ids.isEmpty()) return
        val prefs = context.getSharedPreferences("weather", Context.MODE_PRIVATE)
        val lat = prefs.getString("lat", "51.5072") ?: "51.5072"
        val lon = prefs.getString("lon", "-0.1276") ?: "-0.1276"
        EXECUTOR.execute {
            try {
                val connection = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code,is_day&timezone=auto").openConnection() as HttpURLConnection
                connection.connectTimeout = 12000
                connection.readTimeout = 12000
                val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                connection.disconnect()
                val current = json.getJSONObject("current")
                val code = current.optInt("weather_code", -1)
                val isDay = current.optInt("is_day", 1) == 1
                val description = weatherDescription(code)
                prefs.edit()
                    .putString("temp", "${current.optDouble("temperature_2m").toInt()}°")
                    .putString("description", description)
                    .putInt("weather_code", code)
                    .putBoolean("is_day", isDay)
                    .putString("details", "رطوبت ${current.optInt("relative_humidity_2m")}٪ · باد ${current.optDouble("wind_speed_10m").toInt()} km/h")
                    .apply()
                ids.forEach { render(context, manager, it) }
            } catch (_: Exception) {
                // Keep the last successful values and illustration while offline.
            }
        }
    }

    private fun render(context: Context, manager: AppWidgetManager, id: Int) {
        val prefs = context.getSharedPreferences("weather", Context.MODE_PRIVATE)
        val views = RemoteViews(context.packageName, widgetLayout)
        val code = prefs.getInt("weather_code", -1)
        val isDay = prefs.getBoolean("is_day", true)
        views.setTextViewText(R.id.widget_city, prefs.getString("city", "هوا پیما") ?: "هوا پیما")
        views.setTextViewText(R.id.widget_temp, prefs.getString("temp", "--°") ?: "--°")
        views.setTextViewText(R.id.widget_desc, "${weatherSticker(code, isDay)}  ${prefs.getString("description", "برای دریافت هوا برنامه را باز کنید") ?: ""}")
        views.setTextViewText(R.id.widget_sticker, weatherSticker(code, isDay))
        views.setImageViewResource(R.id.widget_weather_bg, backgroundFor(code, isDay))
        views.setTextViewText(R.id.widget_details, prefs.getString("details", "") ?: "")
        views.setTextViewText(R.id.widget_air, "AQI ${prefs.getString("aqi", "--")}  ·  PM2.5 ${prefs.getString("pm25", "--")}  ·  UV ${prefs.getString("uv", "--")}")
        views.setTextViewText(R.id.widget_updated, "به‌روزرسانی ${prefs.getString("updated", "--:--")}")
        // The three providers have deliberately different information density.
        if (widgetLayout == R.layout.widget_medium || widgetLayout == R.layout.widget_large) {
            views.setTextViewText(R.id.widget_high_low, prefs.getString("widget_high_low", "بیشینه --°  ·  کمینه --°") ?: "")
        }
        if (widgetLayout == R.layout.widget_large) {
            views.setTextViewText(R.id.widget_forecast_hourly, prefs.getString("widget_hourly", "پیش‌بینی ساعتی پس از به‌روزرسانی برنامه نمایش داده می‌شود") ?: "")
            views.setTextViewText(R.id.widget_forecast_daily, prefs.getString("widget_daily", "پیش‌بینی روزانه پس از به‌روزرسانی برنامه نمایش داده می‌شود") ?: "")
        }
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        if (launch != null) {
            val pending = PendingIntent.getActivity(context, id, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pending)
        }
        manager.updateAppWidget(id, views)
    }

    private fun backgroundFor(code: Int, isDay: Boolean): Int = when {
        code == 0 && isDay -> R.drawable.weather_bg_sunny
        code in 1..3 -> R.drawable.weather_bg_cloudy
        code == 45 || code == 48 -> R.drawable.weather_bg_fog
        code in 51..67 || code in 80..82 -> R.drawable.weather_bg_rain
        code in 71..77 || code in 85..86 -> R.drawable.weather_bg_snow
        code in 95..99 -> R.drawable.weather_bg_storm
        !isDay -> R.drawable.weather_bg_night
        else -> R.drawable.weather_bg_cloudy
    }

    private fun weatherDescription(code: Int): String = when (code) {
        0 -> "آسمان صاف"; 1 -> "عمدتاً صاف"; 2 -> "نیمه‌ابری"; 3 -> "ابری"
        45, 48 -> "مه‌آلود"; in 51..57 -> "نم‌نم باران"; in 61..67 -> "بارانی"
        in 71..77 -> "برفی"; in 80..82 -> "رگبار"; in 85..86 -> "رگبار برف"
        in 95..99 -> "رعدوبرق"; else -> "وضعیت هوا"
    }

    private fun weatherSticker(code: Int, isDay: Boolean): String = when (code) {
        0 -> if (isDay) "☀️" else "🌙"
        1 -> if (isDay) "🌤️" else "🌙☁️"
        2 -> "⛅"; 3 -> "☁️"; 45, 48 -> "🌫️"
        in 51..67, in 80..82 -> "🌧️"
        in 71..77, in 85..86 -> "❄️"
        in 95..99 -> "⛈️"; else -> "🌡️"
    }

    companion object {
        const val ACTION_UPDATE_WIDGET = "com.example.havapeyma.UPDATE_WIDGET"
        private val EXECUTOR = Executors.newSingleThreadExecutor()
    }
}

class SmallWeatherWidgetProvider : WeatherWidgetProvider() {
    override val widgetLayout: Int = R.layout.widget_small
}

class MediumWeatherWidgetProvider : WeatherWidgetProvider() {
    override val widgetLayout: Int = R.layout.widget_medium
}

class LargeWeatherWidgetProvider : WeatherWidgetProvider() {
    override val widgetLayout: Int = R.layout.widget_large
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.havapeyma"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.havapeyma"
        minSdk = 24
        targetSdk = 35
        versionCode = 10
        versionName = "1.3.4"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

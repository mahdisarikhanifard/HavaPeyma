package com.example.havapeyma

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val refreshHandler = Handler(Looper.getMainLooper())
    private val automaticRefresh = object : Runnable {
        override fun run() {
            if (!isFinishing) {
                loadWeather()
                refreshHandler.postDelayed(this, AUTO_REFRESH_INTERVAL_MS)
            }
        }
    }
    private lateinit var content: LinearLayout
    private lateinit var cityTitle: TextView
    private lateinit var mainWeather: TextView
    private lateinit var details: TextView
    private lateinit var hourly: TextView
    private lateinit var daily: TextView
    private lateinit var air: TextView
    private lateinit var multiModel: TextView
    private var latitude = 51.5072
    private var longitude = -0.1276
    private var city = "لندن"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("weather", Context.MODE_PRIVATE)
        latitude = prefs.getString("lat", "51.5072")?.toDoubleOrNull() ?: 51.5072
        longitude = prefs.getString("lon", "-0.1276")?.toDoubleOrNull() ?: -0.1276
        city = prefs.getString("city", "لندن") ?: "لندن"
        buildUi()
        loadWeather()
        loadMultiModelAnalysis()
    }

    override fun onResume() {
        super.onResume()
        refreshHandler.removeCallbacks(automaticRefresh)
        refreshHandler.postDelayed(automaticRefresh, AUTO_REFRESH_INTERVAL_MS)
    }

    override fun onPause() {
        refreshHandler.removeCallbacks(automaticRefresh)
        super.onPause()
    }

    override fun onDestroy() {
        refreshHandler.removeCallbacks(automaticRefresh)
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF3F7FA.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 22, 20, 20)
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF126782.toInt(), 0xFF249CB1.toInt())
            ).apply { cornerRadii = floatArrayOf(0f,0f,0f,0f,28f,28f,28f,28f) }
        }
        val brand = TextView(this).apply {
            text = "☀  هوا پیما"
            textSize = 14f
            setTextColor(0xFFDDF7FA.toInt())
            gravity = Gravity.CENTER
        }
        cityTitle = TextView(this).apply {
            textSize = 25f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD); text = city
            setPadding(0, 8, 0, 2)
        }
        val subtitle = TextView(this).apply {
            text = "پیش‌بینی دقیق هوا و پایش کیفیت هوا"
            textSize = 12f; gravity = Gravity.CENTER; setTextColor(0xFFE0F4F7.toInt())
        }
        header.addView(brand); header.addView(cityTitle); header.addView(subtitle)
        header.addView(actionButton("☆ ذخیره شهر فعلی", 0xFF0D566C.toInt()) { saveCurrentCity() },
            LinearLayout.LayoutParams(-2, dp(38)).apply { topMargin = dp(8) })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(8))
        }
        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val refresh = actionButton("به‌روزرسانی", 0xFF126782.toInt()) { loadWeather() }
        val gps = actionButton("موقعیت من", 0xFF287F91.toInt()) { requestGps() }
        val search = actionButton("جست‌وجوی شهر", 0xFF287F91.toInt()) { showCitySearch() }
        val saved = actionButton("شهرهای من", 0xFF287F91.toInt()) { showSavedCities() }
        actionRow.addView(refresh, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(4) })
        actionRow.addView(gps, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(4) })
        actionRow.addView(search, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(4) })
        actionRow.addView(saved, LinearLayout.LayoutParams(0, dp(46), 1f))
        actions.addView(actionRow, LinearLayout.LayoutParams(-1, -2))
        actions.addView(actionButton("⌖ انتخاب نقطه از روی نقشه", 0xFF0D566C.toInt()) { showMapPicker() },
            LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) })

        val scroll = ScrollView(this).apply { clipToPadding = false }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }
        mainWeather = sectionText(34f, 0xFF123B49.toInt(), true)
        details = sectionText(14f, 0xFF42616C.toInt())
        hourly = sectionText(14f, 0xFF294F5C.toInt())
        daily = sectionText(14f, 0xFF294F5C.toInt())
        air = sectionText(14f, 0xFF294F5C.toInt())
        multiModel = sectionText(14f, 0xFF294F5C.toInt())

        val hero = card()
        hero.addView(TextView(this).apply {
            text = "وضعیت فعلی"; textSize = 14f; setTextColor(0xFF63818A.toInt())
        })
        hero.addView(TextView(this).apply {
            text = "🌤️"; textSize = 48f; gravity = Gravity.CENTER; tag = "weather_sticker"
        })
        hero.addView(mainWeather)
        hero.addView(details)
        content.addView(hero)

        addHeading("پیش‌بینی ساعتی · ۶ ساعت آینده")
        val hourlyCard = card(); hourlyCard.addView(hourly); content.addView(hourlyCard)
        addHeading("پیش‌بینی روزانه · ۵ روز آینده")
        val dailyCard = card(); dailyCard.addView(daily); content.addView(dailyCard)
        addHeading("کیفیت هوا و شاخص UV")
        val airCard = card(); airCard.addView(air); content.addView(airCard)
        addHeading("تحلیل هوشمند چندمنبعی · ۳ مدل")
        val analysisCard = card()
        analysisCard.addView(multiModel)
        analysisCard.addView(actionButton("تحلیل دوباره", 0xFF126782.toInt()) { loadMultiModelAnalysis() },
            LinearLayout.LayoutParams(-2, dp(42)).apply { topMargin = dp(8) })
        content.addView(analysisCard)
        content.addView(TextView(this).apply {
            text = "منبع داده: Open-Meteo  •  مقادیر ممکن است با تأخیر به‌روزرسانی شوند"
            textSize = 10f; setTextColor(0xFF81959C.toInt()); gravity = Gravity.CENTER
            setPadding(4, dp(16), 4, dp(8))
        })
        scroll.addView(content)
        root.addView(header)
        root.addView(actions)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(0xFFFFFFFF.toInt()); cornerRadius = dp(18).toFloat()
            setStroke(dp(1), 0xFFE4EDF0.toInt())
        }
        elevation = dp(2).toFloat()
        val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(6)
        layoutParams = lp
    }

    private fun actionButton(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false; setTextColor(0xFFFFFFFF.toInt())
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(color); cornerRadius = dp(13).toFloat()
        }
        setPadding(dp(4), 0, dp(4), 0)
        setOnClickListener { action() }
    }

    private fun sectionText(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(7), 0, dp(7)); text = "در حال دریافت اطلاعات..."
    }

    private fun addHeading(label: String) {
        content.addView(TextView(this).apply {
            text = label; textSize = 16f; setTextColor(0xFF176F86.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(3), dp(16), dp(3), dp(8))
        })
    }

    private fun loadWeather() {
        loadMultiModelAnalysis()
        mainWeather.text = "در حال دریافت وضعیت هوا..."
        executor.execute {
            try {
                val weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m&hourly=temperature_2m,precipitation_probability,uv_index,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max&forecast_days=5&timezone=auto"
                val w = JSONObject(getUrl(weatherUrl))
                val current = w.getJSONObject("current")
                val airUrl = "https://air-quality-api.open-meteo.com/v1/air-quality?latitude=$latitude&longitude=$longitude&current=pm10,pm2_5,us_aqi,european_aqi&timezone=auto"
                val a = try { JSONObject(getUrl(airUrl)).optJSONObject("current") ?: JSONObject() } catch (_: Exception) { JSONObject() }
                val temp = current.optDouble("temperature_2m", Double.NaN)
                val feels = current.optDouble("apparent_temperature", Double.NaN)
                val humidity = current.optInt("relative_humidity_2m", -1)
                val wind = current.optDouble("wind_speed_10m", Double.NaN)
                val windDirection = current.optDouble("wind_direction_10m", Double.NaN)
                val windGust = current.optDouble("wind_gusts_10m", Double.NaN)
                val windText = "سرعت باد ${format(wind)} km/h · جهت ${windDirectionText(windDirection)}\nتندباد ${format(windGust)} km/h · مقیاس بوفورت ${beaufort(wind)}"
                val code = current.optInt("weather_code", -1)
                val hourlyData = w.optJSONObject("hourly") ?: JSONObject()
                val dailyData = w.optJSONObject("daily") ?: JSONObject()
                val hTimes = hourlyData.optJSONArray("time")
                val hTemps = hourlyData.optJSONArray("temperature_2m")
                val hRain = hourlyData.optJSONArray("precipitation_probability")
                val hCodes = hourlyData.optJSONArray("weather_code")
                val hWind = hourlyData.optJSONArray("wind_speed_10m")
                val hWindDir = hourlyData.optJSONArray("wind_direction_10m")
                val hWindGust = hourlyData.optJSONArray("wind_gusts_10m")
                val dCodes = dailyData.optJSONArray("weather_code")
                val dTimes = dailyData.optJSONArray("time")
                val dMax = dailyData.optJSONArray("temperature_2m_max")
                val dMin = dailyData.optJSONArray("temperature_2m_min")
                val dUv = dailyData.optJSONArray("uv_index_max")
                val dSunrise = dailyData.optJSONArray("sunrise")
                val dSunset = dailyData.optJSONArray("sunset")
                val currentHour = current.optString("time", "").take(13)
                val firstHour = if (hTimes != null) (0 until hTimes.length()).firstOrNull { hTimes.optString(it).take(13) >= currentHour } ?: 0 else 0
                val hourText = buildString {
                    if (hTimes != null && hTemps != null) for (i in firstHour until minOf(firstHour + 6, hTimes.length(), hTemps.length())) {
                        val time = hTimes.optString(i).substringAfter('T')
                        val hourCode = hCodes?.optInt(i, code) ?: code
                        append("${weatherSticker(hourCode, true)}  $time  ${hTemps.optDouble(i).toInt()}°")
                        if (hRain != null) append("  احتمال بارش ${hRain.optInt(i)}٪")
                        if (hWind != null) append("  باد ${format(hWind.optDouble(i, Double.NaN))} km/h")
                        if (hWindDir != null) append(" ${windDirectionText(hWindDir.optDouble(i, Double.NaN))}")
                        if (hWindGust != null) append(" · تندباد ${format(hWindGust.optDouble(i, Double.NaN))} km/h")
                        append("\n")
                    }
                }
                val dayText = buildString {
                    if (dTimes != null && dMax != null && dMin != null) for (i in 0 until minOf(5, dTimes.length(), dMax.length(), dMin.length())) {
                        val dayCode = dCodes?.optInt(i, -1) ?: -1
                        append("${weatherSticker(dayCode, true)}  ${dTimes.optString(i)}   بیشینه ${dMax.optDouble(i).toInt()}° / کمینه ${dMin.optDouble(i).toInt()}°")
                        if (dUv != null) append("   UV ${dUv.optDouble(i).toInt()}")
                        if (i == 0 && dSunrise != null && dSunset != null && dSunrise.length() > 0 && dSunset.length() > 0) {
                            append("\nطلوع ${dSunrise.optString(i).substringAfter('T')} · غروب ${dSunset.optString(i).substringAfter('T')}")
                        }
                        append("\n")
                    }
                }
                val aqi = a.optDouble("us_aqi", Double.NaN)
                val uvToday = if (dUv != null && dUv.length() > 0) dUv.optDouble(0) else Double.NaN
                val airText = "کیفیت هوا: ${aqiDescription(aqi)}\nشاخص آمریکا AQI: ${format(aqi)}\nشاخص اروپا: ${format(a.optDouble("european_aqi", Double.NaN))}\nذرات PM2.5: ${format(a.optDouble("pm2_5", Double.NaN))} µg/m³\nذرات PM10: ${format(a.optDouble("pm10", Double.NaN))} µg/m³\nشاخص UV امروز: ${format(uvToday)} · ${uvDescription(uvToday)}"
                val isDay = current.optInt("is_day", 1) == 1
                val currentText = "${weatherSticker(code, isDay)}  ${format(temp)}°  ${weatherDescription(code)}"
                val detailsText = "احساس‌شده ${format(feels)}°   |   رطوبت ${if (humidity >= 0) "$humidity٪" else "--"}\n$windText"
                getSharedPreferences("weather", MODE_PRIVATE).edit()
                    .putString("temp", "${format(temp)}°")
                    .putString("description", weatherDescription(code))
                    .putInt("weather_code", code)
                    .putBoolean("is_day", isDay)
                    .putString("details", "رطوبت ${if (humidity >= 0) "$humidity٪" else "--"} · ${format(wind)} km/h ${windDirectionText(windDirection)} · تندباد ${format(windGust)} km/h · بوفورت ${beaufort(wind)}")
                    .putString("widget_hourly", hourText.trim())
                    .putString("widget_daily", dayText.trim())
                    .putString("widget_high_low", if (dMax != null && dMin != null && dMax.length() > 0 && dMin.length() > 0) "بیشینه ${dMax.optDouble(0).toInt()}°  ·  کمینه ${dMin.optDouble(0).toInt()}°" else "")
                    .putString("aqi", format(a.optDouble("us_aqi", Double.NaN)))
                    .putString("pm25", format(a.optDouble("pm2_5", Double.NaN)))
                    .putString("uv", if (dUv != null && dUv.length() > 0) dUv.optDouble(0).toInt().toString() else "--")
                    .putString("updated", java.text.SimpleDateFormat("HH:mm", Locale.getDefault()).format(java.util.Date()))
                    .putString("city", city).putString("lat", latitude.toString()).putString("lon", longitude.toString()).apply()
                runOnUiThread {
                    cityTitle.text = city
                    mainWeather.text = currentText
                    (content.findViewWithTag<TextView>("weather_sticker"))?.text = weatherSticker(code, isDay)
                    details.text = "$detailsText\nآخرین به‌روزرسانی: ${java.text.SimpleDateFormat("HH:mm", Locale.getDefault()).format(java.util.Date())}"
                    hourly.text = hourText.ifBlank { "اطلاعات ساعتی در دسترس نیست" }
                    daily.text = dayText.ifBlank { "اطلاعات روزانه در دسترس نیست" }
                    air.text = airText
                    sendBroadcast(Intent("com.example.havapeyma.UPDATE_WIDGET").setPackage(packageName))
                }
            } catch (e: Exception) {
                runOnUiThread { mainWeather.text = "دریافت اطلاعات ناموفق بود"; details.text = "اتصال اینترنت را بررسی کنید و دوباره برنامه را باز کنید.\n${e.message ?: "خطای شبکه"}" }
            }
        }
    }

    /** Compares three independent deterministic forecast models for the selected city. */
    private fun loadMultiModelAnalysis() {
        multiModel.text = "در حال دریافت و مقایسه پیش‌بینی مدل‌های ECMWF، GFS و ICON..."
        val lat = latitude
        val lon = longitude
        val selectedCity = city
        executor.execute {
            try {
                val modelIds = listOf("ecmwf_ifs", "ncep_gfs_seamless", "icon_seamless")
                val labels = listOf("ECMWF اروپا", "GFS آمریکا", "ICON آلمان")
                val forecasts = modelIds.mapIndexed { index, model ->
                    val address = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&models=$model&hourly=time,temperature_2m,precipitation_probability,precipitation,wind_speed_10m,wind_gusts_10m&forecast_days=4&timezone=auto"
                    val json = JSONObject(getUrl(address))
                    val hourly = json.optJSONObject("hourly") ?: throw Exception("داده ساعتی از ${labels[index]} دریافت نشد")
                    ModelForecast(labels[index],
                        hourly.optJSONArray("time") ?: org.json.JSONArray(),
                        hourly.optJSONArray("temperature_2m") ?: org.json.JSONArray(),
                        hourly.optJSONArray("precipitation_probability") ?: org.json.JSONArray(),
                        hourly.optJSONArray("precipitation") ?: org.json.JSONArray(),
                        hourly.optJSONArray("wind_speed_10m") ?: org.json.JSONArray(),
                        hourly.optJSONArray("wind_gusts_10m") ?: org.json.JSONArray())
                }
                val firstTime = forecasts.first().times.optString(0)
                if (firstTime.length < 10) throw Exception("زمان‌بندی پیش‌بینی در دسترس نیست")
                val tomorrowDate = java.time.LocalDate.parse(firstTime.substring(0, 10)).plusDays(1).toString()
                val tomorrowIndexes = forecasts.map { forecast ->
                    (0 until forecast.times.length()).filter { forecast.times.optString(it).startsWith(tomorrowDate) }
                }
                val hourIndexes = tomorrowIndexes.reduce { acc, indexes -> acc.intersect(indexes.toSet()).sorted() }
                if (hourIndexes.isEmpty()) throw Exception("پیش‌بینی فردا از مدل‌ها دریافت نشد")
                val tempMeans = hourIndexes.map { h -> forecasts.mapNotNull { it.temps.optDouble(h).takeUnless { it.isNaN() || it.isInfinite() } }.average() }
                val tempSpread = hourIndexes.map { h ->
                    val values = forecasts.mapNotNull { it.temps.optDouble(h).takeUnless { it.isNaN() || it.isInfinite() } }
                    if (values.size < 2) 0.0 else values.max() - values.min()
                }
                val rainProb = hourIndexes.map { h -> forecasts.mapNotNull { it.rainProb.optDouble(h).takeUnless { it.isNaN() || it.isInfinite() } }.average() }
                val rainAmount = hourIndexes.map { h -> forecasts.mapNotNull { it.rain.optDouble(h).takeUnless { it.isNaN() || it.isInfinite() } }.average() }
                val winds = hourIndexes.map { h -> forecasts.mapNotNull { it.wind.optDouble(h).takeUnless { it.isNaN() || it.isInfinite() } }.average() }
                val gusts = hourIndexes.map { h -> forecasts.mapNotNull { it.gust.optDouble(h).takeUnless { it.isNaN() || it.isInfinite() } }.average() }
                val meanTemp = tempMeans.average()
                val maxSpread = tempSpread.maxOrNull() ?: 0.0
                val meanRainProb = rainProb.filterNot { it.isNaN() }.average()
                val totalRain = rainAmount.sum()
                val maxWind = winds.maxOrNull() ?: Double.NaN
                val maxGust = gusts.maxOrNull() ?: Double.NaN
                val minTemp = tempMeans.minOrNull() ?: Double.NaN
                val maxTemp = tempMeans.maxOrNull() ?: Double.NaN
                val confidence = when {
                    maxSpread <= 2.0 -> "خوب (اختلاف دمای مدل‌ها کم است)"
                    maxSpread <= 4.0 -> "متوسط (مقداری اختلاف بین مدل‌ها وجود دارد)"
                    else -> "پایین (مدل‌ها اختلاف قابل‌توجه دارند)"
                }
                val rainNarrative = when {
                    meanRainProb >= 70.0 -> "احتمال بارندگی بالا است؛ برای فعالیت بیرونی آمادگی داشته باشید."
                    meanRainProb >= 40.0 -> "احتمال بارش قابل توجه است، اما زمان و شدت آن ممکن است تغییر کند."
                    meanRainProb >= 20.0 -> "احتمال بارش کم تا متوسط است؛ پیش‌بینی ساعتی را دنبال کنید."
                    else -> "احتمال بارش در مجموع پایین به نظر می‌رسد."
                }
                val windNarrative = when {
                    maxGust >= 60.0 -> "تندباد شدید محتمل است؛ احتیاط لازم است."
                    maxGust >= 40.0 -> "احتمال تندباد نسبتاً شدید وجود دارد."
                    else -> "بر اساس میانگین مدل‌ها، باد شدید پیش‌بینی نمی‌شود."
                }
                val summary = buildString {
                    append("تحلیل و پیش‌بینی فردا ($tomorrowDate) برای $selectedCity\n")
                    append("دمای میانگین: ${format(meanTemp)}°C · کمینه: ${format(minTemp)}°C · بیشینه: ${format(maxTemp)}°C\n")
                    append("بیشترین اختلاف دمای مدل‌ها در طول فردا: تا ${format(maxSpread)}°C\n")
                    append("میانگین احتمال بارش ساعتی: ${format(meanRainProb)}٪ · مجموع بارش برآوردی فردا: ${format(totalRain)} mm\n")
                    append("بیشترین سرعت باد میان مدل‌ها: ${format(maxWind)} km/h · تندباد: ${format(maxGust)} km/h\n")
                    append("میزان اطمینان: $confidence\n")
                    append("تحلیل کلی: $rainNarrative $windNarrative\n\n")
                    append("جزئیات مدل‌ها (میانگین دمای فردا):\n")
                    forecasts.forEachIndexed { index, forecast ->
                        val values = hourIndexes.mapNotNull { forecast.temps.optDouble(it).takeUnless { it.isNaN() || it.isInfinite() } }
                        append("• ${labels[index]}: ${format(values.average())}°C\n")
                    }
                    append("\nاین جمع‌بندی از مقایسه مدل‌هاست، نه تضمین قطعی. برای بازه‌های دورتر عدم‌قطعیت بیشتر می‌شود.")
                }
                runOnUiThread { if (city == selectedCity && latitude == lat && longitude == lon) multiModel.text = summary }
            } catch (e: Exception) {
                runOnUiThread { if (city == selectedCity) multiModel.text = "تحلیل چندمنبعی فعلاً در دسترس نیست.\n${e.message ?: "خطای دریافت داده"}\nبرای تلاش دوباره، دکمه تحلیل دوباره را بزنید." }
            }
        }
    }

    private data class ModelForecast(
        val name: String,
        val times: org.json.JSONArray,
        val temps: org.json.JSONArray,
        val rainProb: org.json.JSONArray,
        val rain: org.json.JSONArray,
        val wind: org.json.JSONArray,
        val gust: org.json.JSONArray
    )

    private fun aqiDescription(value: Double): String = when {
        value.isNaN() -> "نامشخص"
        value <= 50 -> "پاک و مناسب"
        value <= 100 -> "متوسط"
        value <= 150 -> "ناسالم برای گروه‌های حساس"
        value <= 200 -> "ناسالم"
        value <= 300 -> "بسیار ناسالم"
        else -> "خطرناک"
    }

    private fun uvDescription(value: Double): String = when {
        value.isNaN() -> "نامشخص"
        value < 3 -> "کم"
        value < 6 -> "متوسط"
        value < 8 -> "زیاد"
        value < 11 -> "خیلی زیاد"
        else -> "شدید"
    }

    private fun format(value: Double): String = if (value.isNaN() || value.isInfinite()) "--" else String.format(Locale.US, "%.0f", value)

    private fun getUrl(address: String): String {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000; connection.readTimeout = 15000; connection.requestMethod = "GET"
        return try { connection.inputStream.bufferedReader().use { it.readText() } } finally { connection.disconnect() }
    }

    private fun weatherDescription(code: Int): String = when (code) {
        0 -> "آسمان صاف"; 1 -> "عمدتاً صاف"; 2 -> "نیمه‌ابری"; 3 -> "ابری"
        45, 48 -> "مه‌آلود"; 51, 53, 55 -> "نم‌نم باران"; 56, 57 -> "باران یخ‌زن"
        61, 63, 65 -> "بارانی"; 66, 67 -> "باران یخ‌زن"; 71, 73, 75, 77 -> "برفی"
        80, 81, 82 -> "رگبار باران"; 85, 86 -> "رگبار برف"; 95, 96, 99 -> "رعدوبرق"; else -> "وضعیت نامشخص"
    }

    private fun showMapPicker() {
        var selectedLat = latitude
        var selectedLon = longitude
        val webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webViewClient = WebViewClient()
        }
        val status = TextView(this).apply {
            text = "نقطه فعلی: ${"%.5f".format(Locale.US, selectedLat)}, ${"%.5f".format(Locale.US, selectedLon)}\nروی نقشه لمس کنید تا نقطه جابه‌جا شود."
            textSize = 14f
            setTextColor(0xFF254653.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun pointChanged(lat: Double, lon: Double) {
                selectedLat = lat
                selectedLon = lon
                runOnUiThread {
                    status.text = "نقطه انتخابی: ${"%.5f".format(Locale.US, lat)}, ${"%.5f".format(Locale.US, lon)}\nبرای ثبت، دکمه «انتخاب این نقطه» را بزنید."
                }
            }
        }, "MapBridge")

        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(webView, LinearLayout.LayoutParams(-1, dp(430)))
            addView(status, LinearLayout.LayoutParams(-1, -2))
        }
        val html = """<!DOCTYPE html><html lang="fa"><head><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><style>html,body,#map{height:100%;width:100%;margin:0;padding:0}body{font-family:sans-serif}</style></head><body><div id="map"></div><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>const lat=$selectedLat,lon=$selectedLon;const map=L.map('map').setView([lat,lon],10);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);let marker=L.marker([lat,lon]).addTo(map);map.on('click',function(e){marker.setLatLng(e.latlng);MapBridge.pointChanged(e.latlng.lat,e.latlng.lng);});</script></body></html>"""
        webView.loadDataWithBaseURL("https://openstreetmap.org/", html, "text/html", "UTF-8", null)
        val dialog = AlertDialog.Builder(this)
            .setTitle("انتخاب نقطه هواشناسی")
            .setView(holder)
            .setPositiveButton("انتخاب این نقطه") { _, _ ->
                latitude = selectedLat
                longitude = selectedLon
                city = "نقطه نقشه (${"%.4f".format(Locale.US, latitude)}, ${"%.4f".format(Locale.US, longitude)})"
                getSharedPreferences("weather", MODE_PRIVATE).edit()
                    .putString("lat", latitude.toString()).putString("lon", longitude.toString()).putString("city", city).apply()
                cityTitle.text = city
                loadWeather()
                loadMultiModelAnalysis()
            }
            .setNegativeButton("انصراف", null)
            .create()
        dialog.setOnDismissListener { webView.destroy() }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.96).toInt(), (resources.displayMetrics.heightPixels * 0.88).toInt())
    }

    private fun showCitySearch() {
        val input = EditText(this).apply { hint = "نام شهر؛ مانند شیراز" }
        AlertDialog.Builder(this).setTitle("جست‌وجوی شهر").setView(input)
            .setPositiveButton("جست‌وجو") { _, _ -> searchCity(input.text.toString().trim()) }
            .setNegativeButton("انصراف", null).show()
    }

    private fun searchCity(query: String) {
        if (query.isBlank()) return
        executor.execute {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val json = JSONObject(getUrl("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=fa&format=json"))
                val results = json.optJSONArray("results")
                if (results == null || results.length() == 0) throw Exception("شهری با این نام پیدا نشد")
                val item = results.getJSONObject(0)
                latitude = item.getDouble("latitude"); longitude = item.getDouble("longitude")
                city = item.optString("name", query)
                val country = item.optString("country", "")
                if (country.isNotBlank()) city += "، $country"
                getSharedPreferences("weather", MODE_PRIVATE).edit().putString("lat", latitude.toString()).putString("lon", longitude.toString()).putString("city", city).apply()
                runOnUiThread { cityTitle.text = city; loadWeather() }
            } catch (e: Exception) { runOnUiThread { Toast.makeText(this, e.message ?: "خطا در جست‌وجو", Toast.LENGTH_LONG).show() } }
        }
    }

    private fun saveCurrentCity() {
        val prefs = getSharedPreferences("weather", MODE_PRIVATE)
        val list = try { org.json.JSONArray(prefs.getString("saved_cities", "[]") ?: "[]") } catch (_: Exception) { org.json.JSONArray() }
        val updated = org.json.JSONArray()
        var replaced = false
        for (i in 0 until list.length()) {
            val item = list.optJSONObject(i) ?: continue
            if (item.optString("name").equals(city, true)) {
                updated.put(JSONObject().put("name", city).put("lat", latitude).put("lon", longitude)); replaced = true
            } else updated.put(item)
        }
        if (!replaced) updated.put(JSONObject().put("name", city).put("lat", latitude).put("lon", longitude))
        prefs.edit().putString("saved_cities", updated.toString()).apply()
        Toast.makeText(this, "شهر «$city» ذخیره شد", Toast.LENGTH_SHORT).show()
    }

    private fun showSavedCities() {
        val prefs = getSharedPreferences("weather", MODE_PRIVATE)
        val list = try { org.json.JSONArray(prefs.getString("saved_cities", "[]") ?: "[]") } catch (_: Exception) { org.json.JSONArray() }
        val names = ArrayList<String>()
        for (i in 0 until list.length()) names.add(list.optJSONObject(i)?.optString("name") ?: "")
        if (names.isEmpty()) {
            AlertDialog.Builder(this).setTitle("شهرهای ذخیره‌شده")
                .setMessage("هنوز شهری ذخیره نشده است. ابتدا شهر را جست‌وجو یا با GPS انتخاب کنید، سپس گزینه «ذخیره شهر فعلی» را بزنید.")
                .setPositiveButton("متوجه شدم", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("انتخاب شهر ذخیره‌شده")
            .setItems(names.toTypedArray()) { _, which ->
                val item = list.optJSONObject(which) ?: return@setItems
                city = item.optString("name", "شهر")
                latitude = item.optDouble("lat", latitude)
                longitude = item.optDouble("lon", longitude)
                prefs.edit().putString("city", city).putString("lat", latitude.toString()).putString("lon", longitude.toString()).apply()
                cityTitle.text = city
                loadWeather()
            }
            .setNeutralButton("ذخیره شهر فعلی") { _, _ -> saveCurrentCity() }
            .setNegativeButton("بستن", null).show()
    }

    private fun weatherSticker(code: Int, isDay: Boolean): String = when (code) {
        0 -> if (isDay) "☀️" else "🌙"
        1 -> if (isDay) "🌤️" else "🌙☁️"
        2 -> "⛅"; 3 -> "☁️"
        45, 48 -> "🌫️"
        51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> "🌧️"
        71, 73, 75, 77, 85, 86 -> "❄️"
        95, 96, 99 -> "⛈️"
        else -> "🌡️"
    }

    private fun requestGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 41); return
        }
        try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            val location: Location? = manager.getProviders(true).asSequence().mapNotNull { provider -> try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null } }.maxByOrNull { it.time }
            if (location == null) { Toast.makeText(this, "موقعیت در دسترس نیست؛ GPS را روشن کنید یا شهر را جست‌وجو کنید.", Toast.LENGTH_LONG).show(); return }
            latitude = location.latitude; longitude = location.longitude; city = "موقعیت من"
            getSharedPreferences("weather", MODE_PRIVATE).edit().putString("lat", latitude.toString()).putString("lon", longitude.toString()).putString("city", city).apply()
            cityTitle.text = city; loadWeather()
        } catch (_: SecurityException) { Toast.makeText(this, "اجازه مکان‌یابی داده نشد", Toast.LENGTH_SHORT).show() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) requestGps()
        else if (requestCode == 41) Toast.makeText(this, "برای استفاده از GPS باید اجازه مکان‌یابی بدهید.", Toast.LENGTH_LONG).show()
    }
    private fun windDirectionText(degrees: Double): String {
        if (degrees.isNaN() || degrees.isInfinite()) return "نامشخص"
        val directions = arrayOf("شمال", "شمال‌شرق", "شرق", "جنوب‌شرق", "جنوب", "جنوب‌غرب", "غرب", "شمال‌غرب")
        return directions[((degrees + 22.5) / 45.0).toInt() % 8] + " (${degrees.toInt()}°)"
    }

    private fun beaufort(speed: Double): Int = when {
        speed.isNaN() || speed < 0 -> 0
        speed < 1 -> 0; speed < 6 -> 1; speed < 12 -> 2; speed < 20 -> 3
        speed < 29 -> 4; speed < 39 -> 5; speed < 50 -> 6; speed < 62 -> 7
        speed < 75 -> 8; speed < 89 -> 9; speed < 103 -> 10; speed < 118 -> 11
        else -> 12
    }

    companion object { private const val AUTO_REFRESH_INTERVAL_MS = 30L * 60L * 1000L }

}

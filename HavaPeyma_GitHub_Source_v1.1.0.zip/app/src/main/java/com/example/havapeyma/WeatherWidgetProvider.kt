package com.example.havapeyma

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class WeatherWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        refresh(context, manager, ids)
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
        render(context, manager, appWidgetId, newOptions)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_UPDATE_WIDGET) {
            val manager = AppWidgetManager.getInstance(context)
            refresh(context, manager, manager.getAppWidgetIds(ComponentName(context, WeatherWidgetProvider::class.java)))
        }
    }

    private fun refresh(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { render(context, manager, it, manager.getAppWidgetOptions(it)) }
        if (ids.isEmpty()) return
        val prefs = context.getSharedPreferences("weather", Context.MODE_PRIVATE)
        val lat = prefs.getString("lat", "51.5072") ?: "51.5072"
        val lon = prefs.getString("lon", "-0.1276") ?: "-0.1276"
        EXECUTOR.execute {
            try {
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&timezone=auto")
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() }); c.disconnect()
                val current = json.getJSONObject("current")
                val code = current.optInt("weather_code", -1)
                val description = when (code) {
                    0 -> "آسمان صاف"; 1 -> "عمدتاً صاف"; 2 -> "نیمه‌ابری"; 3 -> "ابری"
                    45, 48 -> "مه‌آلود"; in 51..67 -> "بارانی"; in 71..77 -> "برفی"
                    in 80..82 -> "رگبار"; in 95..99 -> "رعدوبرق"; else -> "وضعیت هوا"
                }
                prefs.edit()
                    .putString("temp", "${current.optDouble("temperature_2m").toInt()}°")
                    .putString("description", description)
                    .putString("details", "رطوبت ${current.optInt("relative_humidity_2m")}٪ · باد ${current.optDouble("wind_speed_10m").toInt()} km/h")
                    .apply()
                ids.forEach { render(context, manager, it, manager.getAppWidgetOptions(it)) }
            } catch (_: Exception) { /* Preserve last successful values while offline. */ }
        }
    }

    private fun render(context: Context, manager: AppWidgetManager, id: Int, options: Bundle) {
        val width = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 110)
        val height = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 90)
        val layout = when {
            width >= 280 && height >= 150 -> R.layout.widget_large
            width >= 190 && height >= 100 -> R.layout.widget_medium
            else -> R.layout.widget_small
        }
        val prefs = context.getSharedPreferences("weather", Context.MODE_PRIVATE)
        val views = RemoteViews(context.packageName, layout)
        views.setTextViewText(R.id.widget_city, prefs.getString("city", "هوا پیما") ?: "هوا پیما")
        views.setTextViewText(R.id.widget_temp, prefs.getString("temp", "--°") ?: "--°")
        views.setTextViewText(R.id.widget_desc, prefs.getString("description", "برای دریافت هوا برنامه را باز کنید") ?: "")
        views.setTextViewText(R.id.widget_details, prefs.getString("details", "") ?: "")
        views.setTextViewText(R.id.widget_air, "AQI ${prefs.getString("aqi", "--")}  ·  PM2.5 ${prefs.getString("pm25", "--")}  ·  UV ${prefs.getString("uv", "--")}")
        views.setTextViewText(R.id.widget_updated, "به‌روزرسانی ${prefs.getString("updated", "--:--")}")
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        if (launch != null) {
            val pending = android.app.PendingIntent.getActivity(context, 0, launch, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pending)
        }
        manager.updateAppWidget(id, views)
    }

    companion object {
        const val ACTION_UPDATE_WIDGET = "com.example.havapeyma.UPDATE_WIDGET"
        private val EXECUTOR = Executors.newSingleThreadExecutor()
    }
}

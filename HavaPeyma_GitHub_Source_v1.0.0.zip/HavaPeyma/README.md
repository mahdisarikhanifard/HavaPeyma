# هوا پیما (HavaPeyma)

Android weather app in Kotlin using Open-Meteo. Includes city search, last-known GPS location, saved location, current weather, hourly/daily forecast, and an Android home-screen widget.

## Build APK with GitHub Actions
1. Upload the contents of this project to the root of a GitHub repository (keep `.github/workflows/build-apk.yml`).
2. Open **Actions** → **Build HavaPeyma APK** → **Run workflow**.
3. When the workflow finishes, download **HavaPeyma-debug-apk** from the run's Artifacts section.

Application ID: `com.example.havapeyma` (initial project identity; confirm before changing).

Weather data: Open-Meteo APIs. Internet is required. GPS requires Android location permission and location services.

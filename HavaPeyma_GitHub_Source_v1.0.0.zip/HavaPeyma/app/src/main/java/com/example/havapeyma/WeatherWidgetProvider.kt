package com.example.havapeyma

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews
import org.json.JSONObject
import kotlin.concurrent.thread

class WeatherWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        updateAll(context)
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, WeatherWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isEmpty()) return
            val prefs = context.getSharedPreferences("weather", Context.MODE_PRIVATE)
            val city = prefs.getString("city", "تهران") ?: "تهران"
            val lat = prefs.getFloat("lat", 35.6892f).toDouble()
            val lon = prefs.getFloat("lon", 51.3890f).toDouble()
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.weather_widget)
                views.setTextViewText(R.id.widget_city, city)
                views.setTextViewText(R.id.widget_temp, "…°")
                views.setTextViewText(R.id.widget_details, "در حال دریافت اطلاعات")
                manager.updateAppWidget(id, views)
            }
            thread {
                try {
                    val json = JSONObject(MainActivity.get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,precipitation,uv_index&timezone=auto"))
                    val current = json.getJSONObject("current")
                    val temperature = "${current.optDouble("temperature_2m").toInt()}°"
                    val detail = "حس‌شده ${current.optDouble("apparent_temperature").toInt()}°  •  رطوبت ${current.optInt("relative_humidity_2m")}%\nباد ${current.optDouble("wind_speed_10m").toInt()} km/h  •  UV ${current.optDouble("uv_index")}"
                    ids.forEach { id ->
                        val views = RemoteViews(context.packageName, R.layout.weather_widget)
                        views.setTextViewText(R.id.widget_city, city)
                        views.setTextViewText(R.id.widget_temp, temperature)
                        views.setTextViewText(R.id.widget_details, detail)
                        manager.updateAppWidget(id, views)
                    }
                } catch (_: Exception) {
                    ids.forEach { id ->
                        val views = RemoteViews(context.packageName, R.layout.weather_widget)
                        views.setTextViewText(R.id.widget_city, city)
                        views.setTextViewText(R.id.widget_temp, "--°")
                        views.setTextViewText(R.id.widget_details, "اتصال به هواشناسی ممکن نشد")
                        manager.updateAppWidget(id, views)
                    }
                }
            }
        }
    }
}

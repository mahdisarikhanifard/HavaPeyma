package com.example.havapeyma

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.*
import android.view.ViewGroup
import android.graphics.Color
import android.view.Gravity
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import java.net.HttpURLConnection
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var cityInput: EditText
    private lateinit var output: TextView
    private lateinit var prefs: android.content.SharedPreferences
    private val blue = Color.rgb(25, 105, 180)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("weather", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 22, 22, 18); setBackgroundColor(Color.rgb(244, 249, 255)) }
        val title = TextView(this).apply { text = "هوا پیما"; textSize = 27f; setTextColor(blue); gravity = Gravity.CENTER; setPadding(0, 0, 0, 14) }
        root.addView(title)
        cityInput = EditText(this).apply { hint = "نام شهر را وارد کنید"; setSingleLine(true); setText(prefs.getString("city", "تهران")) }
        root.addView(cityInput, LinearLayout.LayoutParams(-1, -2))
        val search = Button(this).apply { text = "جستجوی شهر و نمایش هوا"; setOnClickListener { searchCity(cityInput.text.toString().trim()) } }
        root.addView(search)
        val gps = Button(this).apply { text = "استفاده از موقعیت GPS"; setOnClickListener { useGps() } }
        root.addView(gps)
        output = TextView(this).apply { textSize = 16f; setTextColor(Color.rgb(30, 48, 65)); setPadding(4, 18, 4, 4) }
        root.addView(ScrollView(this).apply { addView(output) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        loadSaved()
    }

    private fun searchCity(city: String) {
        if (city.isBlank()) { cityInput.error = "نام شهر را وارد کنید"; return }
        output.text = "در حال جستجوی شهر و دریافت اطلاعات..."
        thread {
            try {
                val q = URLEncoder.encode(city, "UTF-8")
                val geo = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=fa&format=json"))
                val results = geo.optJSONArray("results")
                if (results == null || results.length() == 0) throw Exception("شهر پیدا نشد؛ نام را انگلیسی یا دقیق‌تر وارد کنید.")
                val item = results.getJSONObject(0)
                val lat = item.getDouble("latitude"); val lon = item.getDouble("longitude")
                val label = item.optString("name", city) + if (item.optString("country").isNotBlank()) "، ${item.optString("country")}" else ""
                prefs.edit().putString("city", label).putFloat("lat", lat.toFloat()).putFloat("lon", lon.toFloat()).apply()
                WeatherWidgetProvider.updateAll(this)
                showWeather(label, lat, lon)
            } catch (e: Exception) { runOnUiThread { output.text = "خطا: ${e.message ?: "دریافت اطلاعات ممکن نشد"}" } }
        }
    }

    private fun useGps() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 41); return
        }
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val location: Location? = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (location == null) { output.text = "موقعیت GPS در دسترس نیست. مکان‌یابی را روشن کنید و دوباره تلاش کنید."; return }
            val lat = location.latitude; val lon = location.longitude
            prefs.edit().putString("city", "موقعیت فعلی").putFloat("lat", lat.toFloat()).putFloat("lon", lon.toFloat()).apply()
            WeatherWidgetProvider.updateAll(this)
            showWeather("موقعیت فعلی", lat, lon)
        } catch (e: Exception) { output.text = "خطای مکان‌یابی: ${e.message}" }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) useGps()
    }

    private fun loadSaved() {
        val lat = prefs.getFloat("lat", 35.6892f).toDouble(); val lon = prefs.getFloat("lon", 51.3890f).toDouble()
        showWeather(prefs.getString("city", "تهران") ?: "تهران", lat, lon)
    }

    private fun showWeather(city: String, lat: Double, lon: Double) {
        thread {
            try {
                val forecast = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,pressure_msl,wind_speed_10m,wind_direction_10m,uv_index&hourly=temperature_2m,precipitation_probability,relative_humidity_2m,uv_index&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset,uv_index_max&forecast_days=7&timezone=auto"))
                val c = forecast.getJSONObject("current"); val units = forecast.getJSONObject("current_units")
                val air = try { JSONObject(get("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=$lat&longitude=$lon&current=european_aqi,us_aqi,pm2_5,pm10,uv_index&hourly=pm2_5,pm10,european_aqi&forecast_days=1&timezone=auto")).getJSONObject("current") } catch (_: Exception) { JSONObject() }
                val hourly = forecast.getJSONObject("hourly"); val daily = forecast.getJSONObject("daily")
                val result = buildString {
                    append("📍 $city\n\n")
                    append("🌡 دمای فعلی: ${c.optDouble("temperature_2m", 0.0)} ${units.optString("temperature_2m", "°C")}\n")
                    append("حس‌شده: ${c.optDouble("apparent_temperature", 0.0)}° | رطوبت: ${c.optInt("relative_humidity_2m")}%\n")
                    append("باد: ${c.optDouble("wind_speed_10m")} ${units.optString("wind_speed_10m", "km/h")}، جهت ${c.optInt("wind_direction_10m")}°\n")
                    append("فشار: ${c.optDouble("pressure_msl")} hPa | بارش: ${c.optDouble("precipitation")} mm\n")
                    append("شاخص UV: ${c.optDouble("uv_index")}\n\n")
                    append("کیفیت هوا\nAQI اروپا: ${air.optInt("european_aqi", -1)} | AQI آمریکا: ${air.optInt("us_aqi", -1)}\nPM2.5: ${air.optDouble("pm2_5", -1.0)} µg/m³ | PM10: ${air.optDouble("pm10", -1.0)} µg/m³\n\n")
                    append("پیش‌بینی ساعتی (۶ ساعت آینده)\n")
                    val times = hourly.optJSONArray("time"); val temps = hourly.optJSONArray("temperature_2m"); val probs = hourly.optJSONArray("precipitation_probability")
                    val currentTime = c.optString("time")
                    var start = 0
                    if (times != null) for (i in 0 until times.length()) if (times.optString(i) >= currentTime) { start = i; break }
                    if (times != null && temps != null) for (i in start until minOf(start + 6, times.length())) append("${times.optString(i).takeLast(5)}  ${temps.optDouble(i)}°  بارش ${probs?.optInt(i) ?: 0}%\n")
                    append("\nپیش‌بینی روزانه\n")
                    val dates = daily.optJSONArray("time"); val highs = daily.optJSONArray("temperature_2m_max"); val lows = daily.optJSONArray("temperature_2m_min"); val rain = daily.optJSONArray("precipitation_probability_max"); val uv = daily.optJSONArray("uv_index_max")
                    if (dates != null) for (i in 0 until minOf(7, dates.length())) append("${dates.optString(i)}  ${lows?.optDouble(i)}° تا ${highs?.optDouble(i)}° | بارش ${rain?.optInt(i) ?: 0}% | UV ${uv?.optDouble(i) ?: 0.0}\n")
                    append("\nاطلاعات هواشناسی از Open-Meteo دریافت می‌شود.")
                }
                runOnUiThread { output.text = result }
            } catch (e: Exception) { runOnUiThread { output.text = "خطا در دریافت هواشناسی: ${e.message}" } }
        }
    }

    companion object {
        fun get(url: String): String {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = 15000; readTimeout = 20000; requestMethod = "GET" }
            return try { conn.inputStream.bufferedReader().use { it.readText() } } finally { conn.disconnect() }
        }
    }
}
